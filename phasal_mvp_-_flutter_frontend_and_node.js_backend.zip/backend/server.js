const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Mock data for analysis responses
const analysisResponses = {
  'diseased_leaf.jpg': {
    analysis_type: 'Crop Health',
    disease_name: 'Leaf Blight',
    solution: 'Apply Mancozeb fungicide, 2 grams per liter of water.',
    source: 'Gemini Vision'
  },
  'soil_sample.jpg': {
    analysis_type: 'Soil Health',
    soil_type: 'Alluvial Soil',
    recommendation: 'Good for wheat and rice. Nitrogen content is low, consider adding Urea.',
    source: 'Gemini Vision + Agri DB'
  },
  'cloudy_sky.jpg': {
    analysis_type: 'Weather',
    weather: 'Cloudy Sky',
    recommendation: 'Light rain is expected in the next 2-3 hours. Avoid irrigation today.',
    source: 'Weather API + AI Crop Forecasting'
  }
};

// Default response for unknown images
const defaultAnalysisResponse = {
  analysis_type: 'General Analysis',
  recommendation: 'Image analyzed successfully. For better results, please take clear photos of crops, soil, or sky.',
  source: 'Gemini Vision'
};

// Chatbot responses based on keywords
const getChatbotResponse = (query) => {
  const lowerQuery = query.toLowerCase();
  
  if (lowerQuery.includes('weather') || lowerQuery.includes('मौसम')) {
    return { response: 'अगले 2 दिनों में हल्की बारिश की संभावना है। तापमान 25-30°C रहेगा। खेतों में पानी का उचित प्रबंधन करें।' };
  }
  
  if (lowerQuery.includes('price') || lowerQuery.includes('मंडी') || lowerQuery.includes('भाव')) {
    return { response: 'आज पटना मंडी में गेहूं का भाव ₹2200 प्रति क्विंटल है। चावल ₹3200 और टमाटर ₹1500 प्रति क्विंटल बिक रहा है।' };
  }
  
  if (lowerQuery.includes('scheme') || lowerQuery.includes('योजना') || lowerQuery.includes('yojana')) {
    return { response: 'किसान सम्मान निधि योजना के लिए आप ऑनलाइन आवेदन कर सकते हैं। PM-KISAN पोर्टल पर जाकर रजिस्ट्रेशन करें। अधिक जानकारी के लिए अपने कृषि सलाहकार से संपर्क करें।' };
  }
  
  if (lowerQuery.includes('fertilizer') || lowerQuery.includes('खाद') || lowerQuery.includes('उर्वरक')) {
    return { response: 'मिट्टी की जांच के बाद उर्वरक का उपयोग करें। नाइट्रोजन के लिए यूरिया, फास्फोरस के लिए DAP, और पोटाश के लिए MOP का उपयोग करें।' };
  }
  
  if (lowerQuery.includes('disease') || lowerQuery.includes('रोग') || lowerQuery.includes('बीमारी')) {
    return { response: 'फसल में रोग दिखने पर तुरंत कृषि विशेषज्ञ से सलाह लें। नीम का तेल या जैविक कीटनाशक का उपयोग करें। रोगग्रस्त पत्तियों को हटा दें।' };
  }
  
  if (lowerQuery.includes('irrigation') || lowerQuery.includes('सिंचाई') || lowerQuery.includes('पानी')) {
    return { response: 'फसल की अवस्था के अनुसार सिंचाई करें। ड्रिप इरिगेशन सबसे अच्छा तरीका है। सुबह या शाम के समय सिंचाई करें।' };
  }
  
  // Default response
  return { response: 'मैं अभी सीख रहा हूँ। कृपया फसल, मौसम, मंडी भाव, सरकारी योजनाओं, या कृषि से जुड़ा सवाल पूछें। मैं आपकी मदद करने की कोशिश करूंगा।' };
};

// Routes
app.get('/', (req, res) => {
  res.json({ 
    message: 'PHASAL Backend API is running!',
    endpoints: ['/analyze', '/chatbot'],
    version: '1.0.0'
  });
});

// Image analysis endpoint
app.post('/analyze', (req, res) => {
  try {
    const { filename } = req.body;
    
    if (!filename) {
      return res.status(400).json({ error: 'Filename is required' });
    }
    
    console.log(`Analyzing image: ${filename}`);
    
    // Check if we have a specific response for this filename
    const response = analysisResponses[filename] || defaultAnalysisResponse;
    
    // Simulate processing delay
    setTimeout(() => {
      res.json(response);
    }, 1000);
    
  } catch (error) {
    console.error('Error in /analyze:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Chatbot endpoint
app.post('/chatbot', (req, res) => {
  try {
    const { query } = req.body;
    
    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }
    
    console.log(`Chatbot query: ${query}`);
    
    const response = getChatbotResponse(query);
    
    // Simulate processing delay
    setTimeout(() => {
      res.json(response);
    }, 500);
    
  } catch (error) {
    console.error('Error in /chatbot:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

app.listen(PORT, () => {
  console.log(`🚀 PHASAL Backend server is running on port ${PORT}`);
  console.log(`📱 API endpoints available at http://localhost:${PORT}`);
  console.log(`🔍 Health check: http://localhost:${PORT}/health`);
});
