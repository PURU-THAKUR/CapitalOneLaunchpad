import React, { useState, useEffect } from 'react';
import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import SplashScreen from './components/SplashScreen';
import LanguageSelector from './components/LanguageSelector';
import HomeScreen from './components/HomeScreen';
import CropCalendar from './components/CropCalendar';
import SoilAnalysis from './components/SoilAnalysis';
import CropHealthDetection from './components/CropHealthDetection';
import WeatherAdvice from './components/WeatherAdvice';
import MandiPrices from './components/MandiPrices';
import AIChatbot from './components/AIChatbot';
import CropWasteUpcycling from './components/CropWasteUpcycling';
import EmergencyHelp from './components/EmergencyHelp';
import ComplaintSystem from './components/ComplaintSystem';
import FarmerNetwork from './components/FarmerNetwork';
import HarvestPlanner from './components/HarvestPlanner';
import SchemesForms from './components/SchemesForms';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('hindi'); // Default to Hindi
  const [currentScreen, setCurrentScreen] = useState('home');

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
      // Check if language was previously selected
      const savedLanguage = localStorage.getItem('phasal-language');
      if (!savedLanguage) {
        setShowLanguageSelector(true);
      } else {
        setSelectedLanguage(savedLanguage);
      }
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  const handleLanguageSelect = (language: string) => {
    setSelectedLanguage(language);
    localStorage.setItem('phasal-language', language);
    setShowLanguageSelector(false);
  };

  if (showSplash) {
    return <SplashScreen />;
  }

  if (showLanguageSelector) {
    return (
      <LanguageSelector
        onLanguageSelect={handleLanguageSelect}
        onClose={() => setShowLanguageSelector(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-green-50">
      <Content 
        currentScreen={currentScreen} 
        setCurrentScreen={setCurrentScreen}
        selectedLanguage={selectedLanguage}
        setShowLanguageSelector={setShowLanguageSelector}
      />
      <Toaster />
    </div>
  );
}

function Content({ 
  currentScreen, 
  setCurrentScreen, 
  selectedLanguage,
  setShowLanguageSelector 
}: { 
  currentScreen: string, 
  setCurrentScreen: (screen: string) => void,
  selectedLanguage: string,
  setShowLanguageSelector: (show: boolean) => void
}) {
  const renderScreen = () => {
    const screenProps = {
      setCurrentScreen,
      selectedLanguage,
      setShowLanguageSelector
    };

    switch (currentScreen) {
      case 'home':
        return <HomeScreen {...screenProps} />;
      case 'crop-calendar':
        return <CropCalendar {...screenProps} />;
      case 'soil-analysis':
        return <SoilAnalysis {...screenProps} />;
      case 'crop-health':
        return <CropHealthDetection {...screenProps} />;
      case 'weather':
        return <WeatherAdvice {...screenProps} />;
      case 'mandi-prices':
        return <MandiPrices {...screenProps} />;
      case 'chatbot':
        return <AIChatbot {...screenProps} />;
      case 'waste-upcycling':
        return <CropWasteUpcycling {...screenProps} />;
      case 'emergency':
        return <EmergencyHelp {...screenProps} />;
      case 'complaints':
        return <ComplaintSystem {...screenProps} />;
      case 'network':
        return <FarmerNetwork {...screenProps} />;
      case 'harvest-planner':
        return <HarvestPlanner {...screenProps} />;
      case 'schemes':
        return <SchemesForms {...screenProps} />;
      default:
        return <HomeScreen {...screenProps} />;
    }
  };

  return (
    <div className="min-h-screen">
      {renderScreen()}
    </div>
  );
}
