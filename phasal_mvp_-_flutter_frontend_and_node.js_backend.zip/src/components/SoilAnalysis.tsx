import React, { useState } from 'react';
import { useMutation } from 'convex/react';
import { api } from '../../convex/_generated/api';

interface SoilAnalysisProps {
  setCurrentScreen: (screen: string) => void;
}

const SoilAnalysis: React.FC<SoilAnalysisProps> = ({ setCurrentScreen }) => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [soilTestData, setSoilTestData] = useState({
    ph: '',
    nitrogen: '',
    phosphorus: '',
    potassium: '',
    organicMatter: ''
  });

  const generateUploadUrl = useMutation(api.files.generateUploadUrl);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      analyzeImage(file);
    }
  };

  const analyzeImage = async (file: File) => {
    setIsAnalyzing(true);
    
    // Mock analysis - in production, integrate with Gemini Vision API
    setTimeout(() => {
      const mockResult = {
        soilType: 'दोमट मिट्टी (Loamy Soil)',
        ph: '6.8 (उदासीन)',
        fertility: 'मध्यम उर्वरता',
        nutrients: {
          nitrogen: 'कम',
          phosphorus: 'मध्यम',
          potassium: 'अच्छा'
        },
        recommendations: [
          'यूरिया का प्रयोग करें (50 किलो प्रति एकड़)',
          'जैविक खाद मिलाएं',
          'हरी खाद का उपयोग करें',
          'मिट्टी में नमी बनाए रखें'
        ],
        suitableCrops: ['गेहूं', 'चावल', 'मक्का', 'सरसों'],
        confidence: 85
      };
      
      setAnalysisResult(mockResult);
      setIsAnalyzing(false);
    }, 2000);
  };

  const analyzeSoilData = () => {
    const ph = parseFloat(soilTestData.ph);
    const nitrogen = parseFloat(soilTestData.nitrogen);
    const phosphorus = parseFloat(soilTestData.phosphorus);
    const potassium = parseFloat(soilTestData.potassium);

    let recommendations = [];
    let soilCondition = 'अच्छी';

    if (ph < 6.0) {
      recommendations.push('मिट्टी अम्लीय है - चूना मिलाएं');
      soilCondition = 'सुधार की आवश्यकता';
    } else if (ph > 8.0) {
      recommendations.push('मिट्टी क्षारीय है - जिप्सम का प्रयोग करें');
      soilCondition = 'सुधार की आवश्यकता';
    }

    if (nitrogen < 200) {
      recommendations.push('नाइट्रोजन कम है - यूरिया का प्रयोग करें');
    }

    if (phosphorus < 15) {
      recommendations.push('फास्फोरस कम है - DAP का प्रयोग करें');
    }

    if (potassium < 150) {
      recommendations.push('पोटाश कम है - MOP का प्रयोग करें');
    }

    if (recommendations.length === 0) {
      recommendations.push('मिट्टी की स्थिति अच्छी है');
      recommendations.push('नियमित जैविक खाद का प्रयोग करते रहें');
    }

    setAnalysisResult({
      soilType: 'लैब टेस्ट रिपोर्ट',
      ph: `${ph} ${ph < 6 ? '(अम्लीय)' : ph > 8 ? '(क्षारीय)' : '(उदासीन)'}`,
      fertility: soilCondition,
      nutrients: {
        nitrogen: nitrogen < 200 ? 'कम' : nitrogen > 400 ? 'अधिक' : 'मध्यम',
        phosphorus: phosphorus < 15 ? 'कम' : phosphorus > 30 ? 'अधिक' : 'मध्यम',
        potassium: potassium < 150 ? 'कम' : potassium > 300 ? 'अधिक' : 'मध्यम'
      },
      recommendations,
      confidence: 95
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brown-50 to-green-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="px-4 py-4 flex items-center">
          <button
            onClick={() => setCurrentScreen('home')}
            className="mr-4 p-2 rounded-full bg-brown-100 text-brown-600"
          >
            ←
          </button>
          <div className="flex items-center">
            <span className="text-2xl mr-3">🌱</span>
            <div>
              <h1 className="text-xl font-bold text-gray-800">मिट्टी विश्लेषण</h1>
              <p className="text-sm text-gray-600">Soil Analysis</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        {/* Analysis Options */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4">विश्लेषण का तरीका चुनें</h3>
          
          {/* Image Upload */}
          <div className="mb-6">
            <h4 className="font-medium text-gray-700 mb-3 flex items-center">
              <span className="mr-2">📸</span>
              मिट्टी की फोटो अपलोड करें
            </h4>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
                id="soil-image"
              />
              <label htmlFor="soil-image" className="cursor-pointer">
                {selectedImage ? (
                  <div>
                    <img
                      src={URL.createObjectURL(selectedImage)}
                      alt="Selected soil"
                      className="w-32 h-32 object-cover rounded-lg mx-auto mb-2"
                    />
                    <p className="text-sm text-gray-600">{selectedImage.name}</p>
                  </div>
                ) : (
                  <div>
                    <span className="text-4xl mb-2 block">📷</span>
                    <p className="text-gray-600">मिट्टी की फोटो लें या अपलोड करें</p>
                  </div>
                )}
              </label>
            </div>
          </div>

          {/* Manual Data Entry */}
          <div>
            <h4 className="font-medium text-gray-700 mb-3 flex items-center">
              <span className="mr-2">📊</span>
              लैब टेस्ट रिपोर्ट डेटा
            </h4>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">pH</label>
                <input
                  type="number"
                  step="0.1"
                  value={soilTestData.ph}
                  onChange={(e) => setSoilTestData({...soilTestData, ph: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-lg"
                  placeholder="6.5"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">नाइट्रोजन (kg/ha)</label>
                <input
                  type="number"
                  value={soilTestData.nitrogen}
                  onChange={(e) => setSoilTestData({...soilTestData, nitrogen: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-lg"
                  placeholder="250"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">फास्फोरस (kg/ha)</label>
                <input
                  type="number"
                  value={soilTestData.phosphorus}
                  onChange={(e) => setSoilTestData({...soilTestData, phosphorus: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-lg"
                  placeholder="20"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">पोटाश (kg/ha)</label>
                <input
                  type="number"
                  value={soilTestData.potassium}
                  onChange={(e) => setSoilTestData({...soilTestData, potassium: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-lg"
                  placeholder="200"
                />
              </div>
            </div>
            <button
              onClick={analyzeSoilData}
              className="w-full bg-brown-500 text-white py-3 rounded-lg font-medium hover:bg-brown-600 transition-colors"
            >
              डेटा का विश्लेषण करें
            </button>
          </div>
        </div>

        {/* Loading */}
        {isAnalyzing && (
          <div className="bg-white rounded-xl shadow-md p-6 mb-6 text-center">
            <div className="animate-spin w-8 h-8 border-4 border-brown-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-gray-600">मिट्टी का विश्लेषण हो रहा है...</p>
          </div>
        )}

        {/* Analysis Results */}
        {analysisResult && !isAnalyzing && (
          <div className="bg-white rounded-xl shadow-md p-4 mb-20">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center">
              <span className="mr-2">📋</span>
              विश्लेषण परिणाम
            </h3>

            <div className="space-y-4">
              <div className="p-3 bg-brown-50 rounded-lg">
                <p className="font-medium text-gray-800">मिट्टी का प्रकार</p>
                <p className="text-brown-600">{analysisResult.soilType}</p>
              </div>

              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="font-medium text-gray-800">pH स्तर</p>
                <p className="text-blue-600">{analysisResult.ph}</p>
              </div>

              <div className="p-3 bg-green-50 rounded-lg">
                <p className="font-medium text-gray-800">उर्वरता स्थिति</p>
                <p className="text-green-600">{analysisResult.fertility}</p>
              </div>

              {/* Nutrients */}
              <div className="p-3 bg-purple-50 rounded-lg">
                <p className="font-medium text-gray-800 mb-2">पोषक तत्व</p>
                <div className="grid grid-cols-3 gap-2 text-sm">
                  <div className="text-center">
                    <p className="font-medium">नाइट्रोजन</p>
                    <p className={`${analysisResult.nutrients.nitrogen === 'कम' ? 'text-red-600' : 
                                   analysisResult.nutrients.nitrogen === 'अधिक' ? 'text-orange-600' : 'text-green-600'}`}>
                      {analysisResult.nutrients.nitrogen}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="font-medium">फास्फोरस</p>
                    <p className={`${analysisResult.nutrients.phosphorus === 'कम' ? 'text-red-600' : 
                                   analysisResult.nutrients.phosphorus === 'अधिक' ? 'text-orange-600' : 'text-green-600'}`}>
                      {analysisResult.nutrients.phosphorus}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="font-medium">पोटाश</p>
                    <p className={`${analysisResult.nutrients.potassium === 'कम' ? 'text-red-600' : 
                                   analysisResult.nutrients.potassium === 'अधिक' ? 'text-orange-600' : 'text-green-600'}`}>
                      {analysisResult.nutrients.potassium}
                    </p>
                  </div>
                </div>
              </div>

              {/* Recommendations */}
              <div className="p-3 bg-yellow-50 rounded-lg">
                <p className="font-medium text-gray-800 mb-2">सुझाव</p>
                <ul className="space-y-1">
                  {analysisResult.recommendations.map((rec: string, index: number) => (
                    <li key={index} className="text-yellow-800 text-sm flex items-start">
                      <span className="mr-2">•</span>
                      {rec}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Suitable Crops */}
              {analysisResult.suitableCrops && (
                <div className="p-3 bg-green-50 rounded-lg">
                  <p className="font-medium text-gray-800 mb-2">उपयुक्त फसलें</p>
                  <div className="flex flex-wrap gap-2">
                    {analysisResult.suitableCrops.map((crop: string, index: number) => (
                      <span key={index} className="bg-green-200 text-green-800 px-2 py-1 rounded-full text-sm">
                        {crop}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Confidence */}
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="font-medium text-gray-800">विश्वसनीयता</p>
                <div className="flex items-center mt-1">
                  <div className="flex-1 bg-gray-200 rounded-full h-2 mr-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full" 
                      style={{ width: `${analysisResult.confidence}%` }}
                    ></div>
                  </div>
                  <span className="text-sm text-gray-600">{analysisResult.confidence}%</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SoilAnalysis;
