import React from 'react';

interface LanguageSelectorProps {
  onLanguageSelect: (language: string) => void;
  onClose: () => void;
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({ onLanguageSelect, onClose }) => {
  const languages = [
    // Primary languages at top
    { code: 'english', name: 'English', nativeName: 'English', flag: '🇺🇸', primary: true },
    { code: 'hindi', name: 'Hindi', nativeName: 'हिंदी', flag: '🇮🇳', primary: true },
    
    // Other languages
    { code: 'bhojpuri', name: 'Bhojpuri', nativeName: 'भोजपुरी', flag: '🇮🇳', primary: false },
    { code: 'bengali', name: 'Bengali', nativeName: 'বাংলা', flag: '🇧🇩', primary: false },
    { code: 'tamil', name: 'Tamil', nativeName: 'தமிழ்', flag: '🇮🇳', primary: false },
    { code: 'telugu', name: 'Telugu', nativeName: 'తెలుగు', flag: '🇮🇳', primary: false },
    { code: 'marathi', name: 'Marathi', nativeName: 'मराठी', flag: '🇮🇳', primary: false },
    { code: 'gujarati', name: 'Gujarati', nativeName: 'ગુજરાતી', flag: '🇮🇳', primary: false },
    { code: 'kannada', name: 'Kannada', nativeName: 'ಕನ್ನಡ', flag: '🇮🇳', primary: false },
    { code: 'punjabi', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', flag: '🇮🇳', primary: false },
    { code: 'urdu', name: 'Urdu', nativeName: 'اردو', flag: '🇵🇰', primary: false },
    { code: 'spanish', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸', primary: false },
    { code: 'french', name: 'French', nativeName: 'Français', flag: '🇫🇷', primary: false },
    { code: 'german', name: 'German', nativeName: 'Deutsch', flag: '🇩🇪', primary: false },
    { code: 'portuguese', name: 'Portuguese', nativeName: 'Português', flag: '🇵🇹', primary: false },
    { code: 'russian', name: 'Russian', nativeName: 'Русский', flag: '🇷🇺', primary: false },
    { code: 'chinese', name: 'Chinese', nativeName: '中文', flag: '🇨🇳', primary: false },
    { code: 'japanese', name: 'Japanese', nativeName: '日本語', flag: '🇯🇵', primary: false },
    { code: 'korean', name: 'Korean', nativeName: '한국어', flag: '🇰🇷', primary: false },
    { code: 'arabic', name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦', primary: false },
  ];

  const primaryLanguages = languages.filter(lang => lang.primary);
  const otherLanguages = languages.filter(lang => !lang.primary);

  const handleLanguageSelect = (languageCode: string) => {
    onLanguageSelect(languageCode);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[80vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-500 to-blue-500 text-white p-6 text-center">
          <div className="text-4xl mb-2">🌍</div>
          <h2 className="text-xl font-bold mb-1">Select Language</h2>
          <p className="text-sm opacity-90">भाषा चुनें</p>
        </div>

        <div className="p-4 overflow-y-auto max-h-96">
          {/* Primary Languages */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-gray-600 mb-3 uppercase tracking-wide">
              Recommended / सुझावित
            </h3>
            <div className="space-y-2">
              {primaryLanguages.map((language) => (
                <button
                  key={language.code}
                  onClick={() => handleLanguageSelect(language.code)}
                  className="w-full flex items-center p-4 rounded-xl border-2 border-gray-200 hover:border-green-500 hover:bg-green-50 transition-all duration-200 group"
                >
                  <span className="text-3xl mr-4">{language.flag}</span>
                  <div className="flex-1 text-left">
                    <p className="font-semibold text-gray-800 group-hover:text-green-700">
                      {language.name}
                    </p>
                    <p className="text-sm text-gray-600 group-hover:text-green-600">
                      {language.nativeName}
                    </p>
                  </div>
                  <div className="text-green-500 opacity-0 group-hover:opacity-100 transition-opacity">
                    →
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Other Languages */}
          <div>
            <h3 className="text-sm font-semibold text-gray-600 mb-3 uppercase tracking-wide">
              Other Languages / अन्य भाषाएं
            </h3>
            <div className="grid grid-cols-1 gap-2">
              {otherLanguages.map((language) => (
                <button
                  key={language.code}
                  onClick={() => handleLanguageSelect(language.code)}
                  className="flex items-center p-3 rounded-lg border border-gray-200 hover:border-blue-400 hover:bg-blue-50 transition-all duration-200 group"
                >
                  <span className="text-2xl mr-3">{language.flag}</span>
                  <div className="flex-1 text-left">
                    <p className="font-medium text-gray-800 group-hover:text-blue-700 text-sm">
                      {language.name}
                    </p>
                    <p className="text-xs text-gray-600 group-hover:text-blue-600">
                      {language.nativeName}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-gray-200 p-4 bg-gray-50">
          <p className="text-xs text-gray-500 text-center">
            You can change language anytime from settings
          </p>
          <p className="text-xs text-gray-500 text-center">
            आप सेटिंग्स से कभी भी भाषा बदल सकते हैं
          </p>
        </div>
      </div>
    </div>
  );
};

export default LanguageSelector;
