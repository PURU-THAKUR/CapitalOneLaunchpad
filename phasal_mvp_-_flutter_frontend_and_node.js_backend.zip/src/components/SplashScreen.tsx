import React from 'react';

const SplashScreen = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-400 via-green-500 to-green-600 flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-20 h-20 bg-white rounded-full"></div>
        <div className="absolute top-32 right-16 w-16 h-16 bg-white rounded-full"></div>
        <div className="absolute bottom-20 left-20 w-24 h-24 bg-white rounded-full"></div>
        <div className="absolute bottom-40 right-10 w-12 h-12 bg-white rounded-full"></div>
      </div>

      {/* Wheat Logo */}
      <div className="mb-8 animate-bounce">
        <div className="w-24 h-24 bg-yellow-400 rounded-full flex items-center justify-center shadow-2xl">
          <svg className="w-16 h-16 text-yellow-800" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2L13.09 8.26L20 9L13.09 9.74L12 16L10.91 9.74L4 9L10.91 8.26L12 2Z"/>
            <path d="M12 16L13.09 18.26L16 19L13.09 19.74L12 22L10.91 19.74L8 19L10.91 18.26L12 16Z"/>
          </svg>
        </div>
      </div>

      {/* App Name */}
      <h1 className="text-6xl font-bold text-white mb-4 tracking-wider animate-pulse">
        PHASAL
      </h1>
      
      {/* Tagline */}
      <p className="text-xl text-green-100 text-center px-8 mb-8">
        AI-Powered Farming Assistant
      </p>
      <p className="text-lg text-green-200 text-center px-8">
        किसान का डिजिटल साथी
      </p>

      {/* Loading Animation */}
      <div className="mt-12 flex space-x-2">
        <div className="w-3 h-3 bg-white rounded-full animate-bounce"></div>
        <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
        <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
      </div>
    </div>
  );
};

export default SplashScreen;
