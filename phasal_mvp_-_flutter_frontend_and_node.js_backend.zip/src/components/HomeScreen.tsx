import React from 'react';
import { t } from '../utils/translations';

interface HomeScreenProps {
  setCurrentScreen: (screen: string) => void;
  selectedLanguage: string;
  setShowLanguageSelector: (show: boolean) => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ 
  setCurrentScreen, 
  selectedLanguage, 
  setShowLanguageSelector 
}) => {
  const features = [
    {
      id: 'crop-calendar',
      titleKey: 'cropCalendar',
      descKey: 'cropCalendarDesc',
      icon: '📅',
      color: 'bg-blue-500'
    },
    {
      id: 'soil-analysis',
      titleKey: 'soilAnalysis',
      descKey: 'soilAnalysisDesc',
      icon: '🌱',
      color: 'bg-brown-500'
    },
    {
      id: 'crop-health',
      titleKey: 'cropHealth',
      descKey: 'cropHealthDesc',
      icon: '🔍',
      color: 'bg-green-500'
    },
    {
      id: 'weather',
      titleKey: 'weatherAdvice',
      descKey: 'weatherAdviceDesc',
      icon: '🌤️',
      color: 'bg-sky-500'
    },
    {
      id: 'mandi-prices',
      titleKey: 'mandiPrices',
      descKey: 'mandiPricesDesc',
      icon: '💰',
      color: 'bg-yellow-500'
    },
    {
      id: 'chatbot',
      titleKey: 'aiAssistant',
      descKey: 'aiAssistantDesc',
      icon: '🤖',
      color: 'bg-purple-500'
    },
    {
      id: 'waste-upcycling',
      titleKey: 'wasteUpcycling',
      descKey: 'wasteUpcyclingDesc',
      icon: '♻️',
      color: 'bg-teal-500'
    },
    {
      id: 'emergency',
      titleKey: 'emergencyHelp',
      descKey: 'emergencyHelpDesc',
      icon: '🚨',
      color: 'bg-red-500'
    },
    {
      id: 'complaints',
      titleKey: 'complaintSystem',
      descKey: 'complaintSystemDesc',
      icon: '📝',
      color: 'bg-orange-500'
    },
    {
      id: 'network',
      titleKey: 'farmerNetwork',
      descKey: 'farmerNetworkDesc',
      icon: '👥',
      color: 'bg-indigo-500'
    },
    {
      id: 'harvest-planner',
      titleKey: 'harvestPlanner',
      descKey: 'harvestPlannerDesc',
      icon: '🚛',
      color: 'bg-pink-500'
    },
    {
      id: 'schemes',
      titleKey: 'govSchemes',
      descKey: 'govSchemesDesc',
      icon: '🏛️',
      color: 'bg-gray-600'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mr-3">
                <span className="text-2xl">🌾</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">{t(selectedLanguage, 'appName')}</h1>
                <p className="text-sm text-gray-600">{t(selectedLanguage, 'tagline')}</p>
              </div>
            </div>
            
            {/* Language Selector Button */}
            <button
              onClick={() => setShowLanguageSelector(true)}
              className="p-2 rounded-full bg-blue-100 text-blue-600 hover:bg-blue-200 transition-colors"
            >
              🌍
            </button>
          </div>
        </div>
      </div>

      {/* Welcome Message */}
      <div className="px-4 py-6">
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-2">
            {t(selectedLanguage, 'welcome')}
          </h2>
          <p className="text-gray-600">
            {t(selectedLanguage, 'welcomeMessage')}
          </p>
        </div>
      </div>

      {/* Features Grid */}
      <div className="px-4 pb-8">
        <div className="grid grid-cols-2 gap-4">
          {features.map((feature) => (
            <button
              key={feature.id}
              onClick={() => setCurrentScreen(feature.id)}
              className={`${feature.color} rounded-xl p-4 text-white shadow-lg transform transition-all duration-200 hover:scale-105 active:scale-95`}
            >
              <div className="text-3xl mb-2">{feature.icon}</div>
              <h3 className="font-bold text-sm mb-1">{t(selectedLanguage, feature.titleKey)}</h3>
              <p className="text-xs opacity-80">{t(selectedLanguage, feature.descKey)}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Status Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2">
        <div className="flex items-center justify-between text-xs text-gray-600">
          <div className="flex items-center">
            <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
            <span>{t(selectedLanguage, 'online')}</span>
          </div>
          <div className="flex items-center">
            <span>📍 {t(selectedLanguage, 'location')}</span>
          </div>
          <div className="flex items-center">
            <span>🌡️ {t(selectedLanguage, 'temperature')}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomeScreen;
