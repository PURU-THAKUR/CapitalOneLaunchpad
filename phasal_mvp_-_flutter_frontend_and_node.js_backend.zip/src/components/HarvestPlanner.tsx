import React, { useState } from 'react';

interface HarvestPlannerProps {
  setCurrentScreen: (screen: string) => void;
}

const HarvestPlanner: React.FC<HarvestPlannerProps> = ({ setCurrentScreen }) => {
  const [selectedCrop, setSelectedCrop] = useState('wheat');
  const [farmSize, setFarmSize] = useState('');
  const [harvestDate, setHarvestDate] = useState('');

  const crops = [
    { id: 'wheat', name: 'गेहूं', icon: '🌾', season: 'रबी' },
    { id: 'rice', name: 'चावल', icon: '🌾', season: 'खरीफ' },
    { id: 'maize', name: 'मक्का', icon: '🌽', season: 'खरीफ' },
    { id: 'sugarcane', name: 'गन्ना', icon: '🎋', season: 'वार्षिक' }
  ];

  const harvestPlan = {
    wheat: {
      bestTime: 'अप्रैल-मई (सुबह 8-11 बजे)',
      duration: '15-20 दिन',
      laborRequired: '8-10 मजदूर प्रति एकड़',
      equipmentNeeded: ['हार्वेस्टर', 'ट्रैक्टर', 'ट्रॉली'],
      storageAdvice: 'धूप में सुखाकर नमी 12% तक लाएं',
      marketTiming: 'कटाई के तुरंत बाद या 2-3 महीने बाद',
      expectedYield: '40-50 क्विंटल प्रति एकड़',
      qualityChecks: ['दाने का रंग सुनहरा हो', 'नमी 12-14% हो', 'टूटे दाने 2% से कम हों']
    },
    rice: {
      bestTime: 'अक्टूबर-नवंबर (सुबह 9-12 बजे)',
      duration: '20-25 दिन',
      laborRequired: '10-12 मजदूर प्रति एकड़',
      equipmentNeeded: ['कंबाइन हार्वेस्टर', 'ट्रैक्टर', 'ट्रॉली'],
      storageAdvice: 'धूप में सुखाकर नमी 14% तक लाएं',
      marketTiming: 'कटाई के तुरंत बाद बेचना बेहतर',
      expectedYield: '50-60 क्विंटल प्रति एकड़',
      qualityChecks: ['चावल का रंग सफेद हो', 'नमी 14% हो', 'टूटे दाने 5% से कम हों']
    }
  };

  const transportOptions = [
    {
      type: 'ट्रैक्टर ट्रॉली',
      capacity: '3-4 टन',
      cost: '₹500-800 प्रति ट्रिप',
      suitableFor: 'छोटे किसान (1-5 एकड़)',
      icon: '🚜'
    },
    {
      type: 'ट्रक',
      capacity: '8-10 टन',
      cost: '₹1500-2500 प्रति ट्रिप',
      suitableFor: 'मध्यम किसान (5-15 एकड़)',
      icon: '🚛'
    },
    {
      type: 'बड़ा ट्रक',
      capacity: '15-20 टन',
      cost: '₹3000-5000 प्रति ट्रिप',
      suitableFor: 'बड़े किसान (15+ एकड़)',
      icon: '🚚'
    }
  ];

  const nearbyMarkets = [
    { name: 'पटना मंडी', distance: '25 किमी', price: '₹2200/क्विंटल', rating: 4.2 },
    { name: 'दरभंगा मंडी', distance: '45 किमी', price: '₹2150/क्विंटल', rating: 3.8 },
    { name: 'मुजफ्फरपुर मंडी', distance: '35 किमी', price: '₹2180/क्विंटल', rating: 4.0 }
  ];

  const currentPlan = harvestPlan[selectedCrop as keyof typeof harvestPlan] || harvestPlan.wheat;

  const calculateEstimatedIncome = () => {
    if (!farmSize) return 0;
    const size = parseFloat(farmSize);
    const yieldRange = currentPlan.expectedYield.match(/(\d+)-(\d+)/);
    if (yieldRange) {
      const avgYield = (parseInt(yieldRange[1]) + parseInt(yieldRange[2])) / 2;
      const totalYield = size * avgYield;
      const avgPrice = 2200; // Average price per quintal
      return totalYield * avgPrice;
    }
    return 0;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="px-4 py-4 flex items-center">
          <button
            onClick={() => setCurrentScreen('home')}
            className="mr-4 p-2 rounded-full bg-pink-100 text-pink-600"
          >
            ←
          </button>
          <div className="flex items-center">
            <span className="text-2xl mr-3">🚛</span>
            <div>
              <h1 className="text-xl font-bold text-gray-800">फसल योजनाकार</h1>
              <p className="text-sm text-gray-600">Harvest Planner</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        {/* Crop Selection */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4">फसल चुनें</h3>
          
          <div className="grid grid-cols-2 gap-3">
            {crops.map((crop) => (
              <button
                key={crop.id}
                onClick={() => setSelectedCrop(crop.id)}
                className={`p-3 rounded-lg border-2 transition-all ${
                  selectedCrop === crop.id
                    ? 'border-pink-500 bg-pink-50'
                    : 'border-gray-200 bg-white'
                }`}
              >
                <div className="text-2xl mb-1">{crop.icon}</div>
                <p className="text-sm font-medium text-gray-800">{crop.name}</p>
                <p className="text-xs text-gray-600">{crop.season}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Farm Details */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4">खेत की जानकारी</h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                खेत का आकार (एकड़ में)
              </label>
              <input
                type="number"
                value={farmSize}
                onChange={(e) => setFarmSize(e.target.value)}
                placeholder="जैसे: 5"
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                कटाई की तारीख
              </label>
              <input
                type="date"
                value={harvestDate}
                onChange={(e) => setHarvestDate(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500"
              />
            </div>
          </div>
        </div>

        {/* Harvest Plan */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">📋</span>
            कटाई योजना
          </h3>

          <div className="space-y-4">
            <div className="p-3 bg-green-50 rounded-lg">
              <p className="font-medium text-green-800">सबसे अच्छा समय</p>
              <p className="text-green-700 text-sm">{currentPlan.bestTime}</p>
            </div>

            <div className="p-3 bg-blue-50 rounded-lg">
              <p className="font-medium text-blue-800">अवधि</p>
              <p className="text-blue-700 text-sm">{currentPlan.duration}</p>
            </div>

            <div className="p-3 bg-yellow-50 rounded-lg">
              <p className="font-medium text-yellow-800">मजदूर की आवश्यकता</p>
              <p className="text-yellow-700 text-sm">{currentPlan.laborRequired}</p>
            </div>

            <div className="p-3 bg-purple-50 rounded-lg">
              <p className="font-medium text-purple-800">उपकरण</p>
              <div className="flex flex-wrap gap-2 mt-1">
                {currentPlan.equipmentNeeded.map((equipment, index) => (
                  <span key={index} className="bg-purple-200 text-purple-800 px-2 py-1 rounded-full text-xs">
                    {equipment}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-3 bg-orange-50 rounded-lg">
              <p className="font-medium text-orange-800">भंडारण सलाह</p>
              <p className="text-orange-700 text-sm">{currentPlan.storageAdvice}</p>
            </div>
          </div>
        </div>

        {/* Expected Income */}
        {farmSize && (
          <div className="bg-green-500 text-white rounded-xl p-4 mb-6">
            <h3 className="font-bold mb-2 flex items-center">
              <span className="mr-2">💰</span>
              अनुमानित आय
            </h3>
            <p className="text-2xl font-bold">₹{calculateEstimatedIncome().toLocaleString()}</p>
            <p className="text-green-100 text-sm">
              {currentPlan.expectedYield} × {farmSize} एकड़ × ₹2200/क्विंटल
            </p>
          </div>
        )}

        {/* Transport Options */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">🚛</span>
            परिवहन विकल्प
          </h3>

          <div className="space-y-3">
            {transportOptions.map((option, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <span className="text-2xl mr-3">{option.icon}</span>
                    <div>
                      <p className="font-medium text-gray-800">{option.type}</p>
                      <p className="text-sm text-gray-600">{option.capacity}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-600">{option.cost}</p>
                  </div>
                </div>
                <p className="text-xs text-gray-500">{option.suitableFor}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Nearby Markets */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-20">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">🏪</span>
            नजदीकी मंडी
          </h3>

          <div className="space-y-3">
            {nearbyMarkets.map((market, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <p className="font-medium text-gray-800">{market.name}</p>
                    <p className="text-sm text-gray-600">{market.distance}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-600">{market.price}</p>
                    <div className="flex items-center">
                      <span className="text-yellow-500 mr-1">⭐</span>
                      <span className="text-sm text-gray-600">{market.rating}</span>
                    </div>
                  </div>
                </div>
                <button className="w-full bg-pink-500 text-white py-2 rounded-lg text-sm hover:bg-pink-600 transition-colors">
                  रूट देखें
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HarvestPlanner;
