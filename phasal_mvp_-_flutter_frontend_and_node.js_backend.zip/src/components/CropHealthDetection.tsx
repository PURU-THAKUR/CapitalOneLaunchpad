import React, { useState } from 'react';
import { useMutation } from 'convex/react';
import { api } from '../../convex/_generated/api';

interface CropHealthDetectionProps {
  setCurrentScreen: (screen: string) => void;
}

const CropHealthDetection: React.FC<CropHealthDetectionProps> = ({ setCurrentScreen }) => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [cropType, setCropType] = useState('wheat');

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      analyzeCropHealth(file);
    }
  };

  const takePicture = () => {
    // In a real app, this would open the camera
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.capture = 'environment';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        setSelectedImage(file);
        analyzeCropHealth(file);
      }
    };
    input.click();
  };

  const analyzeCropHealth = async (file: File) => {
    setIsAnalyzing(true);
    
    // Mock analysis - in production, integrate with Gemini Vision API
    setTimeout(() => {
      const diseases = [
        {
          name: 'पत्ती झुलसा रोग (Leaf Blight)',
          severity: 'मध्यम',
          confidence: 87,
          symptoms: ['पत्तियों पर भूरे धब्बे', 'पत्तियों का पीला होना', 'किनारों का सूखना'],
          treatment: [
            'मैंकोजेब फंगीसाइड का छिड़काव (2 ग्राम प्रति लीटर)',
            'संक्रमित पत्तियों को हटाएं',
            'हवा का संचार बढ़ाएं',
            '7 दिन बाद दोबारा छिड़काव करें'
          ],
          prevention: [
            'बीज उपचार करें',
            'उचित दूरी पर बुआई करें',
            'अधिक पानी न दें',
            'खेत की सफाई रखें'
          ]
        },
        {
          name: 'कीट आक्रमण (Pest Attack)',
          severity: 'कम',
          confidence: 65,
          symptoms: ['पत्तियों पर छेद', 'कीड़ों की उपस्थिति'],
          treatment: [
            'नीम का तेल का छिड़काव',
            'जैविक कीटनाशक का प्रयोग'
          ],
          prevention: [
            'नियमित निरीक्षण',
            'साफ-सफाई'
          ]
        }
      ];

      const randomDisease = diseases[Math.floor(Math.random() * diseases.length)];
      
      setAnalysisResult({
        disease: randomDisease,
        overallHealth: randomDisease.severity === 'कम' ? 'अच्छी' : 'सुधार की आवश्यकता',
        recommendations: [
          'तत्काल उपचार शुरू करें',
          'नियमित निरीक्षण करते रहें',
          'मौसम के अनुसार देखभाल करें'
        ]
      });
      setIsAnalyzing(false);
    }, 2500);
  };

  const cropTypes = [
    { value: 'wheat', label: 'गेहूं (Wheat)' },
    { value: 'rice', label: 'चावल (Rice)' },
    { value: 'maize', label: 'मक्का (Maize)' },
    { value: 'tomato', label: 'टमाटर (Tomato)' },
    { value: 'potato', label: 'आलू (Potato)' },
    { value: 'cotton', label: 'कपास (Cotton)' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="px-4 py-4 flex items-center">
          <button
            onClick={() => setCurrentScreen('home')}
            className="mr-4 p-2 rounded-full bg-green-100 text-green-600"
          >
            ←
          </button>
          <div className="flex items-center">
            <span className="text-2xl mr-3">🔍</span>
            <div>
              <h1 className="text-xl font-bold text-gray-800">फसल स्वास्थ्य जांच</h1>
              <p className="text-sm text-gray-600">Crop Health Detection</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        {/* Crop Type Selection */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-3">फसल का प्रकार चुनें</h3>
          <select
            value={cropType}
            onChange={(e) => setCropType(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
          >
            {cropTypes.map(crop => (
              <option key={crop.value} value={crop.value}>{crop.label}</option>
            ))}
          </select>
        </div>

        {/* Image Capture/Upload */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4">फसल की फोटो लें</h3>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            <button
              onClick={takePicture}
              className="bg-green-500 text-white p-4 rounded-lg flex flex-col items-center hover:bg-green-600 transition-colors"
            >
              <span className="text-2xl mb-2">📷</span>
              <span className="font-medium">कैमरा</span>
            </button>
            
            <label className="bg-blue-500 text-white p-4 rounded-lg flex flex-col items-center cursor-pointer hover:bg-blue-600 transition-colors">
              <span className="text-2xl mb-2">📁</span>
              <span className="font-medium">गैलरी</span>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </label>
          </div>

          {selectedImage && (
            <div className="mt-4">
              <img
                src={URL.createObjectURL(selectedImage)}
                alt="Selected crop"
                className="w-full h-48 object-cover rounded-lg"
              />
              <p className="text-sm text-gray-600 mt-2 text-center">{selectedImage.name}</p>
            </div>
          )}
        </div>

        {/* Loading */}
        {isAnalyzing && (
          <div className="bg-white rounded-xl shadow-md p-6 mb-6 text-center">
            <div className="animate-spin w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-gray-600">AI से फसल का विश्लेषण हो रहा है...</p>
            <p className="text-sm text-gray-500 mt-2">कृपया प्रतीक्षा करें</p>
          </div>
        )}

        {/* Analysis Results */}
        {analysisResult && !isAnalyzing && (
          <div className="bg-white rounded-xl shadow-md p-4 mb-20">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center">
              <span className="mr-2">📊</span>
              विश्लेषण परिणाम
            </h3>

            {/* Overall Health */}
            <div className="p-3 bg-green-50 rounded-lg mb-4">
              <p className="font-medium text-gray-800">समग्र स्वास्थ्य</p>
              <p className={`text-lg font-bold ${
                analysisResult.overallHealth === 'अच्छी' ? 'text-green-600' : 'text-orange-600'
              }`}>
                {analysisResult.overallHealth}
              </p>
            </div>

            {/* Disease Information */}
            <div className="p-4 bg-red-50 rounded-lg mb-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-bold text-red-800">{analysisResult.disease.name}</h4>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  analysisResult.disease.severity === 'कम' ? 'bg-yellow-200 text-yellow-800' :
                  analysisResult.disease.severity === 'मध्यम' ? 'bg-orange-200 text-orange-800' :
                  'bg-red-200 text-red-800'
                }`}>
                  {analysisResult.disease.severity}
                </span>
              </div>
              
              <div className="mb-3">
                <p className="font-medium text-gray-800 mb-1">लक्षण:</p>
                <ul className="text-sm text-gray-700">
                  {analysisResult.disease.symptoms.map((symptom: string, index: number) => (
                    <li key={index} className="flex items-start">
                      <span className="mr-2">•</span>
                      {symptom}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mb-3">
                <p className="font-medium text-gray-800 mb-1">विश्वसनीयता:</p>
                <div className="flex items-center">
                  <div className="flex-1 bg-gray-200 rounded-full h-2 mr-2">
                    <div 
                      className="bg-red-500 h-2 rounded-full" 
                      style={{ width: `${analysisResult.disease.confidence}%` }}
                    ></div>
                  </div>
                  <span className="text-sm text-gray-600">{analysisResult.disease.confidence}%</span>
                </div>
              </div>
            </div>

            {/* Treatment */}
            <div className="p-4 bg-blue-50 rounded-lg mb-4">
              <h4 className="font-bold text-blue-800 mb-3 flex items-center">
                <span className="mr-2">💊</span>
                उपचार
              </h4>
              <ul className="space-y-2">
                {analysisResult.disease.treatment.map((treatment: string, index: number) => (
                  <li key={index} className="text-blue-700 text-sm flex items-start">
                    <span className="mr-2 text-blue-500">✓</span>
                    {treatment}
                  </li>
                ))}
              </ul>
            </div>

            {/* Prevention */}
            <div className="p-4 bg-green-50 rounded-lg mb-4">
              <h4 className="font-bold text-green-800 mb-3 flex items-center">
                <span className="mr-2">🛡️</span>
                भविष्य में बचाव
              </h4>
              <ul className="space-y-2">
                {analysisResult.disease.prevention.map((prevention: string, index: number) => (
                  <li key={index} className="text-green-700 text-sm flex items-start">
                    <span className="mr-2 text-green-500">•</span>
                    {prevention}
                  </li>
                ))}
              </ul>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-4">
              <button className="bg-red-500 text-white py-3 rounded-lg font-medium hover:bg-red-600 transition-colors">
                आपातकालीन सहायता
              </button>
              <button className="bg-blue-500 text-white py-3 rounded-lg font-medium hover:bg-blue-600 transition-colors">
                विशेषज्ञ से बात करें
              </button>
            </div>
          </div>
        )}

        {/* Tips */}
        <div className="bg-yellow-50 rounded-xl p-4 mb-20">
          <h4 className="font-bold text-yellow-800 mb-3 flex items-center">
            <span className="mr-2">💡</span>
            बेहतर परिणाम के लिए सुझाव
          </h4>
          <ul className="text-yellow-700 text-sm space-y-1">
            <li>• साफ और स्पष्ट फोटो लें</li>
            <li>• प्राकृतिक रोशनी में फोटो लें</li>
            <li>• प्रभावित हिस्से को नजदीक से दिखाएं</li>
            <li>• कई कोणों से फोटो लें</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default CropHealthDetection;
