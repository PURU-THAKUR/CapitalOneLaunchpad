import React, { useState } from 'react';

interface CropWasteUpcyclingProps {
  setCurrentScreen: (screen: string) => void;
}

const CropWasteUpcycling: React.FC<CropWasteUpcyclingProps> = ({ setCurrentScreen }) => {
  const [selectedWasteType, setSelectedWasteType] = useState('wheat-straw');
  const [wasteQuantity, setWasteQuantity] = useState('');

  const wasteTypes = [
    { id: 'wheat-straw', name: 'गेहूं का पुआल', icon: '🌾' },
    { id: 'rice-straw', name: 'धान का पुआल', icon: '🌾' },
    { id: 'corn-stalks', name: 'मक्का के डंठल', icon: '🌽' },
    { id: 'sugarcane-bagasse', name: 'गन्ने की खोई', icon: '🎋' },
    { id: 'cotton-stalks', name: 'कपास के डंठल', icon: '🌿' },
    { id: 'damaged-fruits', name: 'खराब फल-सब्जी', icon: '🍅' }
  ];

  const upcyclingOptions = {
    'wheat-straw': [
      {
        title: 'जैविक खाद (कंपोस्ट)',
        description: 'पुआल को सड़ाकर उत्तम खाद बनाएं',
        time: '3-4 महीने',
        profit: '₹2-3 प्रति किलो',
        process: [
          'पुआल को छोटे टुकड़ों में काटें',
          'गोबर और मिट्टी के साथ मिलाएं',
          'नमी बनाए रखें और हर 15 दिन में पलटें',
          '3-4 महीने बाद तैयार खाद का उपयोग करें'
        ],
        icon: '🌱'
      },
      {
        title: 'मशरूम उत्पादन',
        description: 'ऑयस्टर मशरूम उगाने के लिए उपयोग',
        time: '45-60 दिन',
        profit: '₹150-200 प्रति किलो',
        process: [
          'पुआल को उबलते पानी में 1 घंटे भिगोएं',
          'ठंडा करके मशरूम के बीज मिलाएं',
          'प्लास्टिक बैग में भरकर छेद करें',
          '15-20 दिन में मशरूम निकलना शुरू हो जाएगा'
        ],
        icon: '🍄'
      },
      {
        title: 'पशु आहार',
        description: 'गाय-भैंस के लिए पौष्टिक चारा',
        time: 'तुरंत उपयोग',
        profit: '₹3-5 प्रति किलो',
        process: [
          'पुआल को छोटे टुकड़ों में काटें',
          'यूरिया घोल (4%) से उपचार करें',
          '24 घंटे बाद पशुओं को खिलाएं',
          'दाना और हरा चारा भी साथ दें'
        ],
        icon: '🐄'
      }
    ],
    'rice-straw': [
      {
        title: 'बायो-गैस उत्पादन',
        description: 'धान के पुआल से गैस बनाएं',
        time: '30-45 दिन',
        profit: '₹5-8 प्रति किलो',
        process: [
          'पुआल को बारीक काटें',
          'गोबर के साथ मिलाकर गैस प्लांट में डालें',
          '30 दिन बाद गैस निकलना शुरू हो जाएगा',
          'बचे हुए स्लरी को खाद के रूप में उपयोग करें'
        ],
        icon: '🔥'
      }
    ],
    'damaged-fruits': [
      {
        title: 'वर्मी कंपोस्ट',
        description: 'केंचुओं की मदद से उत्तम खाद',
        time: '2-3 महीने',
        profit: '₹8-12 प्रति किलो',
        process: [
          'फल-सब्जी को छोटे टुकड़ों में काटें',
          'केंचुओं के साथ मिट्टी में मिलाएं',
          'नमी बनाए रखें',
          '2-3 महीने में तैयार खाद मिलेगी'
        ],
        icon: '🪱'
      }
    ]
  };

  const selectedOptions = upcyclingOptions[selectedWasteType as keyof typeof upcyclingOptions] || [];

  const calculateProfit = (option: any) => {
    if (!wasteQuantity) return 0;
    const quantity = parseFloat(wasteQuantity);
    const profitRange = option.profit.match(/₹(\d+)-(\d+)/);
    if (profitRange) {
      const avgProfit = (parseInt(profitRange[1]) + parseInt(profitRange[2])) / 2;
      return quantity * avgProfit;
    }
    return 0;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-green-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="px-4 py-4 flex items-center">
          <button
            onClick={() => setCurrentScreen('home')}
            className="mr-4 p-2 rounded-full bg-teal-100 text-teal-600"
          >
            ←
          </button>
          <div className="flex items-center">
            <span className="text-2xl mr-3">♻️</span>
            <div>
              <h1 className="text-xl font-bold text-gray-800">फसल अपशिष्ट उपयोग</h1>
              <p className="text-sm text-gray-600">Crop Waste Upcycling</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        {/* Waste Type Selection */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4">अपशिष्ट का प्रकार चुनें</h3>
          
          <div className="grid grid-cols-2 gap-3">
            {wasteTypes.map((type) => (
              <button
                key={type.id}
                onClick={() => setSelectedWasteType(type.id)}
                className={`p-3 rounded-lg border-2 transition-all ${
                  selectedWasteType === type.id
                    ? 'border-teal-500 bg-teal-50'
                    : 'border-gray-200 bg-white'
                }`}
              >
                <div className="text-2xl mb-1">{type.icon}</div>
                <p className="text-sm font-medium text-gray-800">{type.name}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Quantity Input */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-3">मात्रा (किलो में)</h3>
          <input
            type="number"
            value={wasteQuantity}
            onChange={(e) => setWasteQuantity(e.target.value)}
            placeholder="जैसे: 100"
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500"
          />
        </div>

        {/* Upcycling Options */}
        <div className="space-y-4 mb-20">
          {selectedOptions.map((option, index) => (
            <div key={index} className="bg-white rounded-xl shadow-md p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center">
                  <span className="text-2xl mr-3">{option.icon}</span>
                  <h4 className="font-bold text-gray-800">{option.title}</h4>
                </div>
                {wasteQuantity && (
                  <div className="text-right">
                    <p className="text-sm text-gray-600">अनुमानित लाभ</p>
                    <p className="font-bold text-green-600">₹{calculateProfit(option)}</p>
                  </div>
                )}
              </div>
              
              <p className="text-gray-600 mb-3">{option.description}</p>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="p-2 bg-blue-50 rounded">
                  <p className="text-sm text-blue-600 font-medium">समय</p>
                  <p className="text-blue-800">{option.time}</p>
                </div>
                <div className="p-2 bg-green-50 rounded">
                  <p className="text-sm text-green-600 font-medium">लाभ</p>
                  <p className="text-green-800">{option.profit}</p>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="font-medium text-gray-800 mb-2">प्रक्रिया:</p>
                <ol className="space-y-1">
                  {option.process.map((step, stepIndex) => (
                    <li key={stepIndex} className="text-sm text-gray-700 flex items-start">
                      <span className="mr-2 text-teal-600 font-bold">{stepIndex + 1}.</span>
                      {step}
                    </li>
                  ))}
                </ol>
              </div>
              
              <button className="w-full mt-4 bg-teal-500 text-white py-2 rounded-lg font-medium hover:bg-teal-600 transition-colors">
                विस्तृत गाइड देखें
              </button>
            </div>
          ))}
        </div>

        {/* Benefits Section */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">🌍</span>
            पर्यावरणीय लाभ
          </h3>
          
          <div className="space-y-3">
            <div className="flex items-start p-3 bg-green-50 rounded-lg">
              <span className="text-green-600 mr-2">🌱</span>
              <div>
                <p className="font-medium text-green-800">मिट्टी की उर्वरता बढ़ती है</p>
                <p className="text-green-700 text-sm">जैविक खाद से मिट्टी में पोषक तत्व बढ़ते हैं</p>
              </div>
            </div>
            
            <div className="flex items-start p-3 bg-blue-50 rounded-lg">
              <span className="text-blue-600 mr-2">💨</span>
              <div>
                <p className="font-medium text-blue-800">वायु प्रदूषण कम होता है</p>
                <p className="text-blue-700 text-sm">पुआल जलाने की जरूरत नहीं पड़ती</p>
              </div>
            </div>
            
            <div className="flex items-start p-3 bg-purple-50 rounded-lg">
              <span className="text-purple-600 mr-2">💰</span>
              <div>
                <p className="font-medium text-purple-800">अतिरिक्त आय</p>
                <p className="text-purple-700 text-sm">अपशिष्ट से पैसा कमाने का मौका</p>
              </div>
            </div>
          </div>
        </div>

        {/* Success Stories */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-20">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">🏆</span>
            सफलता की कहानियां
          </h3>
          
          <div className="space-y-4">
            <div className="border-l-4 border-green-500 pl-4">
              <h4 className="font-bold text-gray-800">राम किशन जी, पटना</h4>
              <p className="text-gray-600 text-sm mb-2">
                "धान के पुआल से मशरूम उगाकर महीने में ₹15,000 की अतिरिक्त आय हो रही है।"
              </p>
              <p className="text-green-600 text-sm font-medium">मासिक आय: ₹15,000</p>
            </div>
            
            <div className="border-l-4 border-blue-500 pl-4">
              <h4 className="font-bold text-gray-800">सुनीता देवी, दरभंगा</h4>
              <p className="text-gray-600 text-sm mb-2">
                "वर्मी कंपोस्ट बनाकर अपने खेत की उर्वरता बढ़ाई और बाकी खाद बेचकर पैसा भी कमाया।"
              </p>
              <p className="text-blue-600 text-sm font-medium">मासिक आय: ₹8,000</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CropWasteUpcycling;
