import React, { useState } from 'react';
import { useQuery } from 'convex/react';
import { api } from '../../convex/_generated/api';

interface SchemesFormsProps {
  setCurrentScreen: (screen: string) => void;
}

const SchemesForms: React.FC<SchemesFormsProps> = ({ setCurrentScreen }) => {
  const [activeTab, setActiveTab] = useState<'browse' | 'apply'>('browse');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [applicationData, setApplicationData] = useState({
    name: '',
    phone: '',
    aadhaar: '',
    farmSize: '',
    landRecords: '',
    bankAccount: ''
  });

  const schemes = useQuery(api.farming.getSchemes, {
    category: selectedCategory === 'all' ? undefined : selectedCategory
  });

  const categories = [
    { id: 'all', name: 'सभी योजनाएं', icon: '📋' },
    { id: 'Income Support', name: 'आय सहायता', icon: '💰' },
    { id: 'Insurance', name: 'बीमा योजना', icon: '🛡️' },
    { id: 'Subsidy', name: 'सब्सिडी', icon: '🎯' },
    { id: 'Loan', name: 'ऋण योजना', icon: '🏦' }
  ];

  const mockSchemes = [
    {
      name: 'PM-KISAN Samman Nidhi',
      description: 'छोटे और सीमांत किसानों को प्रत्यक्ष आय सहायता',
      benefits: '₹6000 प्रति वर्ष 3 किस्तों में',
      eligibility: ['2 हेक्टेयर तक भूमि', 'भूमि स्वामित्व आवश्यक'],
      documents: ['आधार कार्ड', 'भूमि रिकॉर्ड', 'बैंक खाता'],
      applicationProcess: 'PM-KISAN पोर्टल पर ऑनलाइन आवेदन',
      deadline: '31 मार्च 2024',
      category: 'Income Support',
      status: 'Active'
    },
    {
      name: 'Pradhan Mantri Fasal Bima Yojana',
      description: 'फसल बीमा योजना',
      benefits: 'फसल नुकसान की स्थिति में मुआवजा',
      eligibility: ['सभी किसान', 'बटाईदार भी शामिल'],
      documents: ['आधार कार्ड', 'भूमि रिकॉर्ड', 'बुआई प्रमाण पत्र'],
      applicationProcess: 'बैंक या बीमा कंपनी के माध्यम से',
      deadline: 'बुआई के 10 दिन बाद तक',
      category: 'Insurance',
      status: 'Active'
    },
    {
      name: 'Kisan Credit Card',
      description: 'किसान क्रेडिट कार्ड योजना',
      benefits: 'कम ब्याज दर पर कृषि ऋण',
      eligibility: ['सभी किसान', 'न्यूनतम भूमि आवश्यकता नहीं'],
      documents: ['आधार कार्ड', 'भूमि रिकॉर्ड', 'आय प्रमाण पत्र'],
      applicationProcess: 'नजदीकी बैंक में आवेदन',
      deadline: 'कोई समय सीमा नहीं',
      category: 'Loan',
      status: 'Active'
    }
  ];

  const handleApplicationSubmit = () => {
    if (!applicationData.name || !applicationData.phone || !applicationData.aadhaar) {
      alert('कृपया सभी आवश्यक जानकारी भरें');
      return;
    }
    
    alert('आपका आवेदन सफलतापूर्वक जमा हो गया है। आपको जल्द ही SMS से जानकारी मिलेगी।');
    
    // Reset form
    setApplicationData({
      name: '',
      phone: '',
      aadhaar: '',
      farmSize: '',
      landRecords: '',
      bankAccount: ''
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="px-4 py-4 flex items-center">
          <button
            onClick={() => setCurrentScreen('home')}
            className="mr-4 p-2 rounded-full bg-gray-100 text-gray-600"
          >
            ←
          </button>
          <div className="flex items-center">
            <span className="text-2xl mr-3">🏛️</span>
            <div>
              <h1 className="text-xl font-bold text-gray-800">सरकारी योजनाएं</h1>
              <p className="text-sm text-gray-600">Government Schemes</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-200">
        <div className="px-4">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('browse')}
              className={`py-4 px-2 border-b-2 font-medium text-sm ${
                activeTab === 'browse'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              योजनाएं देखें
            </button>
            <button
              onClick={() => setActiveTab('apply')}
              className={`py-4 px-2 border-b-2 font-medium text-sm ${
                activeTab === 'apply'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              आवेदन करें
            </button>
          </div>
        </div>
      </div>

      <div className="p-4">
        {activeTab === 'browse' ? (
          <>
            {/* Category Filter */}
            <div className="bg-white rounded-xl shadow-md p-4 mb-6">
              <h3 className="font-bold text-gray-800 mb-4">श्रेणी चुनें</h3>
              
              <div className="grid grid-cols-2 gap-3">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      selectedCategory === category.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 bg-white'
                    }`}
                  >
                    <span className="mr-2">{category.icon}</span>
                    <span className="text-sm font-medium">{category.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Schemes List */}
            <div className="space-y-4 mb-20">
              {mockSchemes.map((scheme, index) => (
                <div key={index} className="bg-white rounded-xl shadow-md p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-bold text-gray-800">{scheme.name}</h4>
                    <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                      {scheme.status}
                    </span>
                  </div>
                  
                  <p className="text-gray-600 text-sm mb-3">{scheme.description}</p>
                  
                  <div className="space-y-3">
                    <div className="p-3 bg-green-50 rounded-lg">
                      <p className="font-medium text-green-800 text-sm">लाभ</p>
                      <p className="text-green-700 text-sm">{scheme.benefits}</p>
                    </div>
                    
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <p className="font-medium text-blue-800 text-sm">पात्रता</p>
                      <ul className="text-blue-700 text-sm">
                        {scheme.eligibility.map((criteria, idx) => (
                          <li key={idx} className="flex items-start">
                            <span className="mr-2">•</span>
                            {criteria}
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div className="p-3 bg-yellow-50 rounded-lg">
                      <p className="font-medium text-yellow-800 text-sm">आवश्यक दस्तावेज</p>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {scheme.documents.map((doc, idx) => (
                          <span key={idx} className="bg-yellow-200 text-yellow-800 px-2 py-1 rounded-full text-xs">
                            {doc}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div className="p-3 bg-purple-50 rounded-lg">
                      <p className="font-medium text-purple-800 text-sm">आवेदन प्रक्रिया</p>
                      <p className="text-purple-700 text-sm">{scheme.applicationProcess}</p>
                    </div>
                    
                    <div className="p-3 bg-red-50 rounded-lg">
                      <p className="font-medium text-red-800 text-sm">अंतिम तारीख</p>
                      <p className="text-red-700 text-sm">{scheme.deadline}</p>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => setActiveTab('apply')}
                    className="w-full mt-4 bg-blue-500 text-white py-3 rounded-lg font-medium hover:bg-blue-600 transition-colors"
                  >
                    आवेदन करें
                  </button>
                </div>
              ))}
            </div>
          </>
        ) : (
          <>
            {/* Application Form */}
            <div className="bg-white rounded-xl shadow-md p-4 mb-6">
              <h3 className="font-bold text-gray-800 mb-4">योजना के लिए आवेदन</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    पूरा नाम *
                  </label>
                  <input
                    type="text"
                    value={applicationData.name}
                    onChange={(e) => setApplicationData({...applicationData, name: e.target.value})}
                    placeholder="आपका पूरा नाम"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    मोबाइल नंबर *
                  </label>
                  <input
                    type="tel"
                    value={applicationData.phone}
                    onChange={(e) => setApplicationData({...applicationData, phone: e.target.value})}
                    placeholder="10 अंकों का मोबाइल नंबर"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    आधार नंबर *
                  </label>
                  <input
                    type="text"
                    value={applicationData.aadhaar}
                    onChange={(e) => setApplicationData({...applicationData, aadhaar: e.target.value})}
                    placeholder="12 अंकों का आधार नंबर"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    खेत का आकार (एकड़)
                  </label>
                  <input
                    type="number"
                    value={applicationData.farmSize}
                    onChange={(e) => setApplicationData({...applicationData, farmSize: e.target.value})}
                    placeholder="एकड़ में"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    भूमि रिकॉर्ड नंबर
                  </label>
                  <input
                    type="text"
                    value={applicationData.landRecords}
                    onChange={(e) => setApplicationData({...applicationData, landRecords: e.target.value})}
                    placeholder="खसरा/खतौनी नंबर"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    बैंक खाता नंबर
                  </label>
                  <input
                    type="text"
                    value={applicationData.bankAccount}
                    onChange={(e) => setApplicationData({...applicationData, bankAccount: e.target.value})}
                    placeholder="बैंक खाता नंबर"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <button
                  onClick={handleApplicationSubmit}
                  className="w-full bg-blue-500 text-white py-3 rounded-lg font-medium hover:bg-blue-600 transition-colors"
                >
                  आवेदन जमा करें
                </button>
              </div>
            </div>

            {/* Auto-fill Feature */}
            <div className="bg-white rounded-xl shadow-md p-4 mb-6">
              <h3 className="font-bold text-gray-800 mb-4 flex items-center">
                <span className="mr-2">🤖</span>
                AI ऑटो-फिल
              </h3>
              
              <p className="text-gray-600 text-sm mb-4">
                AI आपकी पिछली जानकारी के आधार पर फॉर्म भर सकता है
              </p>
              
              <button className="w-full bg-purple-500 text-white py-3 rounded-lg font-medium hover:bg-purple-600 transition-colors">
                AI से फॉर्म भरें
              </button>
            </div>

            {/* Help Section */}
            <div className="bg-white rounded-xl shadow-md p-4 mb-20">
              <h3 className="font-bold text-gray-800 mb-4 flex items-center">
                <span className="mr-2">💡</span>
                आवेदन सहायता
              </h3>
              
              <div className="space-y-3">
                <div className="flex items-start p-3 bg-blue-50 rounded-lg">
                  <span className="text-blue-600 mr-2">📋</span>
                  <div>
                    <p className="font-medium text-blue-800">सही जानकारी दें</p>
                    <p className="text-blue-700 text-sm">सभी जानकारी सही और पूरी भरें</p>
                  </div>
                </div>
                
                <div className="flex items-start p-3 bg-green-50 rounded-lg">
                  <span className="text-green-600 mr-2">📄</span>
                  <div>
                    <p className="font-medium text-green-800">दस्तावेज तैयार रखें</p>
                    <p className="text-green-700 text-sm">आधार, भूमि रिकॉर्ड, बैंक पासबुक</p>
                  </div>
                </div>
                
                <div className="flex items-start p-3 bg-yellow-50 rounded-lg">
                  <span className="text-yellow-600 mr-2">⏰</span>
                  <div>
                    <p className="font-medium text-yellow-800">समय सीमा का ध्यान रखें</p>
                    <p className="text-yellow-700 text-sm">अंतिम तारीख से पहले आवेदन करें</p>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default SchemesForms;
