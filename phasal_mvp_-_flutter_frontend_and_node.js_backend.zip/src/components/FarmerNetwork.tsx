import React, { useState } from 'react';

interface FarmerNetworkProps {
  setCurrentScreen: (screen: string) => void;
}

interface Post {
  id: string;
  author: string;
  location: string;
  content: string;
  image?: string;
  likes: number;
  comments: number;
  timestamp: Date;
  category: string;
}

const FarmerNetwork: React.FC<FarmerNetworkProps> = ({ setCurrentScreen }) => {
  const [activeTab, setActiveTab] = useState<'feed' | 'groups' | 'experts'>('feed');
  const [newPost, setNewPost] = useState('');

  const mockPosts: Post[] = [
    {
      id: '1',
      author: 'राम किशन',
      location: 'पटना, बिहार',
      content: 'इस साल गेहूं की फसल बहुत अच्छी हुई है। नई किस्म HD-3086 का उपयोग किया था। 45 क्विंटल प्रति एकड़ उत्पादन मिला। सभी किसान भाइयों को सुझाव देता हूं।',
      likes: 24,
      comments: 8,
      timestamp: new Date('2024-01-14'),
      category: 'success'
    },
    {
      id: '2',
      author: 'सुनीता देवी',
      location: 'दरभंगा, बिहार',
      content: 'टमाटर की फसल में पत्ती मोड़क रोग लग गया है। कोई अच्छा इलाज बताएं। फोटो भी लगा रही हूं।',
      likes: 12,
      comments: 15,
      timestamp: new Date('2024-01-13'),
      category: 'help'
    },
    {
      id: '3',
      author: 'मोहन लाल',
      location: 'मुजफ्फरपुर, बिहार',
      content: 'आज मंडी में धान का भाव ₹3200 प्रति क्विंटल मिल रहा है। कल तक और बढ़ने की उम्मीद है। जिन भाइयों के पास धान है वे रुक सकते हैं।',
      likes: 18,
      comments: 6,
      timestamp: new Date('2024-01-12'),
      category: 'market'
    }
  ];

  const groups = [
    { name: 'बिहार किसान समुदाय', members: 1250, icon: '🌾' },
    { name: 'जैविक खेती', members: 890, icon: '🌱' },
    { name: 'मशरूम उत्पादन', members: 456, icon: '🍄' },
    { name: 'डेयरी फार्मिंग', members: 678, icon: '🐄' },
    { name: 'सब्जी उत्पादन', members: 543, icon: '🥕' },
    { name: 'फल बागवानी', members: 321, icon: '🍎' }
  ];

  const experts = [
    {
      name: 'डॉ. अजय कुमार',
      specialization: 'फसल रोग विशेषज्ञ',
      experience: '15 साल',
      rating: 4.8,
      consultations: 1200,
      avatar: '👨‍🔬'
    },
    {
      name: 'डॉ. प्रिया शर्मा',
      specialization: 'मिट्टी विज्ञान',
      experience: '12 साल',
      rating: 4.9,
      consultations: 980,
      avatar: '👩‍🔬'
    },
    {
      name: 'राजेश गुप्ता',
      specialization: 'जैविक खेती',
      experience: '20 साल',
      rating: 4.7,
      consultations: 1500,
      avatar: '👨‍🌾'
    }
  ];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'help': return 'bg-red-100 text-red-800';
      case 'market': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryText = (category: string) => {
    switch (category) {
      case 'success': return 'सफलता';
      case 'help': return 'सहायता';
      case 'market': return 'मंडी';
      default: return 'सामान्य';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="px-4 py-4 flex items-center">
          <button
            onClick={() => setCurrentScreen('home')}
            className="mr-4 p-2 rounded-full bg-indigo-100 text-indigo-600"
          >
            ←
          </button>
          <div className="flex items-center">
            <span className="text-2xl mr-3">👥</span>
            <div>
              <h1 className="text-xl font-bold text-gray-800">किसान नेटवर्क</h1>
              <p className="text-sm text-gray-600">Farmer Network</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-200">
        <div className="px-4">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('feed')}
              className={`py-4 px-2 border-b-2 font-medium text-sm ${
                activeTab === 'feed'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              फीड
            </button>
            <button
              onClick={() => setActiveTab('groups')}
              className={`py-4 px-2 border-b-2 font-medium text-sm ${
                activeTab === 'groups'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              समूह
            </button>
            <button
              onClick={() => setActiveTab('experts')}
              className={`py-4 px-2 border-b-2 font-medium text-sm ${
                activeTab === 'experts'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              विशेषज्ञ
            </button>
          </div>
        </div>
      </div>

      <div className="p-4">
        {activeTab === 'feed' && (
          <>
            {/* Create Post */}
            <div className="bg-white rounded-xl shadow-md p-4 mb-6">
              <div className="flex items-center mb-3">
                <div className="w-10 h-10 bg-indigo-500 rounded-full flex items-center justify-center mr-3">
                  <span className="text-white font-bold">आप</span>
                </div>
                <div>
                  <p className="font-medium text-gray-800">अपना अनुभव साझा करें</p>
                  <p className="text-sm text-gray-600">पटना, बिहार</p>
                </div>
              </div>
              
              <textarea
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                placeholder="अपनी खेती का अनुभव, समस्या या सुझाव साझा करें..."
                rows={3}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 mb-3"
              />
              
              <div className="flex items-center justify-between">
                <div className="flex space-x-4">
                  <button className="flex items-center text-gray-600 hover:text-indigo-600">
                    <span className="mr-1">📷</span>
                    <span className="text-sm">फोटो</span>
                  </button>
                  <button className="flex items-center text-gray-600 hover:text-indigo-600">
                    <span className="mr-1">📍</span>
                    <span className="text-sm">स्थान</span>
                  </button>
                </div>
                <button className="bg-indigo-500 text-white px-4 py-2 rounded-lg text-sm hover:bg-indigo-600 transition-colors">
                  पोस्ट करें
                </button>
              </div>
            </div>

            {/* Posts Feed */}
            <div className="space-y-4 mb-20">
              {mockPosts.map((post) => (
                <div key={post.id} className="bg-white rounded-xl shadow-md p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center mr-3">
                        <span className="text-white font-bold">{post.author[0]}</span>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">{post.author}</p>
                        <p className="text-sm text-gray-600">{post.location}</p>
                      </div>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(post.category)}`}>
                      {getCategoryText(post.category)}
                    </span>
                  </div>
                  
                  <p className="text-gray-700 mb-3">{post.content}</p>
                  
                  <div className="flex items-center justify-between text-sm text-gray-500 border-t pt-3">
                    <div className="flex space-x-4">
                      <button className="flex items-center hover:text-red-500">
                        <span className="mr-1">❤️</span>
                        <span>{post.likes}</span>
                      </button>
                      <button className="flex items-center hover:text-blue-500">
                        <span className="mr-1">💬</span>
                        <span>{post.comments}</span>
                      </button>
                      <button className="flex items-center hover:text-green-500">
                        <span className="mr-1">📤</span>
                        <span>साझा करें</span>
                      </button>
                    </div>
                    <span>{post.timestamp.toLocaleDateString('hi-IN')}</span>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {activeTab === 'groups' && (
          <div className="space-y-4 mb-20">
            {groups.map((group, index) => (
              <div key={index} className="bg-white rounded-xl shadow-md p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mr-4">
                      <span className="text-2xl">{group.icon}</span>
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800">{group.name}</h3>
                      <p className="text-sm text-gray-600">{group.members} सदस्य</p>
                    </div>
                  </div>
                  <button className="bg-indigo-500 text-white px-4 py-2 rounded-lg text-sm hover:bg-indigo-600 transition-colors">
                    जुड़ें
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'experts' && (
          <div className="space-y-4 mb-20">
            {experts.map((expert, index) => (
              <div key={index} className="bg-white rounded-xl shadow-md p-4">
                <div className="flex items-center mb-3">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                    <span className="text-3xl">{expert.avatar}</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-800">{expert.name}</h3>
                    <p className="text-sm text-gray-600">{expert.specialization}</p>
                    <p className="text-sm text-gray-500">अनुभव: {expert.experience}</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <span className="text-yellow-500 mr-1">⭐</span>
                    <span className="text-sm font-medium">{expert.rating}</span>
                    <span className="text-sm text-gray-500 ml-2">({expert.consultations} परामर्श)</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <button className="bg-green-500 text-white py-2 rounded-lg text-sm hover:bg-green-600 transition-colors">
                    📞 कॉल करें
                  </button>
                  <button className="bg-blue-500 text-white py-2 rounded-lg text-sm hover:bg-blue-600 transition-colors">
                    💬 चैट करें
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default FarmerNetwork;
