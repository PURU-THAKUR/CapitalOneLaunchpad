import React, { useState } from 'react';
import { useQuery } from 'convex/react';
import { api } from '../../convex/_generated/api';

interface CropCalendarProps {
  setCurrentScreen: (screen: string) => void;
}

const CropCalendar: React.FC<CropCalendarProps> = ({ setCurrentScreen }) => {
  const [selectedCrop, setSelectedCrop] = useState('Wheat');
  const [selectedRegion, setSelectedRegion] = useState('North India');
  
  const cropData = useQuery(api.farming.getCropCalendar, {
    cropName: selectedCrop,
    region: selectedRegion
  });

  const crops = ['Wheat', 'Rice', 'Maize', 'Sugarcane', 'Cotton', 'Tomato', 'Potato', 'Onion'];
  const regions = ['North India', 'South India', 'East India', 'West India', 'Central India'];

  const currentMonth = new Date().toLocaleString('hi-IN', { month: 'long' });
  const currentSeason = getCurrentSeason();

  function getCurrentSeason() {
    const month = new Date().getMonth() + 1;
    if (month >= 4 && month <= 6) return 'गर्मी';
    if (month >= 7 && month <= 10) return 'खरीफ';
    return 'रबी';
  }

  const mockRecommendations = {
    'Wheat': {
      currentAdvice: 'रबी सीजन में गेहूं की बुआई का समय है। मिट्टी तैयार करें।',
      sowingTime: 'नवंबर-दिसंबर',
      harvestTime: 'अप्रैल-मई',
      duration: '120-130 दिन',
      soilType: 'दोमट, काली मिट्टी',
      waterNeed: 'मध्यम (4-5 सिंचाई)',
      fertilizer: 'यूरिया, DAP, MOP'
    },
    'Rice': {
      currentAdvice: 'खरीफ सीजन में धान की रोपाई का समय है।',
      sowingTime: 'जून-जुलाई',
      harvestTime: 'अक्टूबर-नवंबर',
      duration: '120-150 दिन',
      soilType: 'चिकनी, दोमट मिट्टी',
      waterNeed: 'अधिक (खड़ा पानी)',
      fertilizer: 'यूरिया, DAP, जिंक सल्फेट'
    }
  };

  const recommendation = mockRecommendations[selectedCrop as keyof typeof mockRecommendations] || mockRecommendations['Wheat'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="px-4 py-4 flex items-center">
          <button
            onClick={() => setCurrentScreen('home')}
            className="mr-4 p-2 rounded-full bg-blue-100 text-blue-600"
          >
            ←
          </button>
          <div className="flex items-center">
            <span className="text-2xl mr-3">📅</span>
            <div>
              <h1 className="text-xl font-bold text-gray-800">फसल कैलेंडर</h1>
              <p className="text-sm text-gray-600">Crop Calendar</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        {/* Current Season Info */}
        <div className="bg-blue-500 text-white rounded-xl p-4 mb-6">
          <h2 className="text-lg font-bold mb-2">वर्तमान सीजन: {currentSeason}</h2>
          <p className="text-blue-100">महीना: {currentMonth}</p>
          <p className="text-blue-100 mt-2">{recommendation.currentAdvice}</p>
        </div>

        {/* Crop and Region Selection */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4">फसल और क्षेत्र चुनें</h3>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">फसल</label>
            <select
              value={selectedCrop}
              onChange={(e) => setSelectedCrop(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              {crops.map(crop => (
                <option key={crop} value={crop}>{crop}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">क्षेत्र</label>
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              {regions.map(region => (
                <option key={region} value={region}>{region}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Crop Information */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">🌾</span>
            {selectedCrop} की जानकारी
          </h3>

          <div className="space-y-4">
            <div className="flex items-center p-3 bg-green-50 rounded-lg">
              <span className="text-2xl mr-3">🌱</span>
              <div>
                <p className="font-medium text-gray-800">बुआई का समय</p>
                <p className="text-green-600">{recommendation.sowingTime}</p>
              </div>
            </div>

            <div className="flex items-center p-3 bg-yellow-50 rounded-lg">
              <span className="text-2xl mr-3">🌾</span>
              <div>
                <p className="font-medium text-gray-800">कटाई का समय</p>
                <p className="text-yellow-600">{recommendation.harvestTime}</p>
              </div>
            </div>

            <div className="flex items-center p-3 bg-blue-50 rounded-lg">
              <span className="text-2xl mr-3">⏱️</span>
              <div>
                <p className="font-medium text-gray-800">फसल अवधि</p>
                <p className="text-blue-600">{recommendation.duration}</p>
              </div>
            </div>

            <div className="flex items-center p-3 bg-brown-50 rounded-lg">
              <span className="text-2xl mr-3">🏔️</span>
              <div>
                <p className="font-medium text-gray-800">उपयुक्त मिट्टी</p>
                <p className="text-brown-600">{recommendation.soilType}</p>
              </div>
            </div>

            <div className="flex items-center p-3 bg-cyan-50 rounded-lg">
              <span className="text-2xl mr-3">💧</span>
              <div>
                <p className="font-medium text-gray-800">पानी की आवश्यकता</p>
                <p className="text-cyan-600">{recommendation.waterNeed}</p>
              </div>
            </div>

            <div className="flex items-center p-3 bg-purple-50 rounded-lg">
              <span className="text-2xl mr-3">🧪</span>
              <div>
                <p className="font-medium text-gray-800">उर्वरक</p>
                <p className="text-purple-600">{recommendation.fertilizer}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Monthly Calendar */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-20">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">📅</span>
            मासिक कैलेंडर
          </h3>

          <div className="grid grid-cols-3 gap-2">
            {['जन', 'फर', 'मार', 'अप्र', 'मई', 'जून', 'जुल', 'अग', 'सित', 'अक्ट', 'नव', 'दिस'].map((month, index) => (
              <div
                key={month}
                className={`p-3 rounded-lg text-center ${
                  index >= 10 || index <= 1 ? 'bg-green-100 text-green-800' : 
                  index >= 5 && index <= 9 ? 'bg-blue-100 text-blue-800' : 
                  'bg-gray-100 text-gray-600'
                }`}
              >
                <p className="font-medium">{month}</p>
                <p className="text-xs mt-1">
                  {index >= 10 || index <= 1 ? 'रबी' : 
                   index >= 5 && index <= 9 ? 'खरीफ' : 'गर्मी'}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CropCalendar;
