import React, { useState, useEffect } from 'react';
import { useQuery } from 'convex/react';
import { api } from '../../convex/_generated/api';

interface WeatherAdviceProps {
  setCurrentScreen: (screen: string) => void;
}

const WeatherAdvice: React.FC<WeatherAdviceProps> = ({ setCurrentScreen }) => {
  const [location, setLocation] = useState('Patna, Bihar');
  const [currentWeather, setCurrentWeather] = useState({
    temperature: 28,
    humidity: 65,
    rainfall: 0,
    windSpeed: 12,
    condition: 'Partly Cloudy',
    forecast: [
      { date: 'आज', temp: 28, condition: 'आंशिक बादल', rainfall: 0, icon: '⛅' },
      { date: 'कल', temp: 30, condition: 'धूप', rainfall: 0, icon: '☀️' },
      { date: 'परसों', temp: 26, condition: 'बारिश', rainfall: 15, icon: '🌧️' },
      { date: '3 दिन', temp: 25, condition: 'बारिश', rainfall: 25, icon: '⛈️' },
      { date: '4 दिन', temp: 29, condition: 'साफ', rainfall: 0, icon: '☀️' }
    ]
  });

  const getWeatherAdvice = () => {
    const temp = currentWeather.temperature;
    const humidity = currentWeather.humidity;
    const rainfall = currentWeather.rainfall;
    
    let advice = [];
    
    if (temp > 35) {
      advice.push('अत्यधिक गर्मी - दिन में सिंचाई न करें');
      advice.push('फसलों को छाया प्रदान करें');
    } else if (temp < 15) {
      advice.push('ठंड से फसलों की सुरक्षा करें');
      advice.push('पाला से बचाव के उपाय करें');
    }
    
    if (humidity > 80) {
      advice.push('अधिक नमी - फंगल रोग का खतरा');
      advice.push('हवा का संचार बढ़ाएं');
    }
    
    if (rainfall > 0) {
      advice.push('बारिश की वजह से सिंचाई न करें');
      advice.push('जल निकासी की व्यवस्था करें');
    } else {
      advice.push('सिंचाई की आवश्यकता हो सकती है');
    }
    
    return advice;
  };

  const getCropSpecificAdvice = () => {
    const season = getCurrentSeason();
    const temp = currentWeather.temperature;
    
    if (season === 'रबी') {
      return [
        'गेहूं की फसल के लिए उपयुक्त मौसम',
        'सरसों की बुआई का समय',
        'मटर और चना की देखभाल करें'
      ];
    } else if (season === 'खरीफ') {
      return [
        'धान की रोपाई के लिए अच्छा समय',
        'मक्का की बुआई करें',
        'कपास की देखभाल करें'
      ];
    } else {
      return [
        'गर्मी की फसलों की तैयारी करें',
        'सिंचाई की व्यवस्था करें',
        'मिट्टी की तैयारी करें'
      ];
    }
  };

  const getCurrentSeason = () => {
    const month = new Date().getMonth() + 1;
    if (month >= 4 && month <= 6) return 'गर्मी';
    if (month >= 7 && month <= 10) return 'खरीफ';
    return 'रबी';
  };

  const getIrrigationAdvice = () => {
    const temp = currentWeather.temperature;
    const humidity = currentWeather.humidity;
    const rainfall = currentWeather.rainfall;
    
    if (rainfall > 10) {
      return {
        recommendation: 'सिंचाई न करें',
        reason: 'पर्याप्त बारिश हो रही है',
        color: 'text-blue-600'
      };
    } else if (temp > 30 && humidity < 50) {
      return {
        recommendation: 'तत्काल सिंचाई करें',
        reason: 'गर्मी और कम नमी',
        color: 'text-red-600'
      };
    } else if (temp > 25 && humidity < 60) {
      return {
        recommendation: 'हल्की सिंचाई करें',
        reason: 'मध्यम तापमान',
        color: 'text-orange-600'
      };
    } else {
      return {
        recommendation: 'सिंचाई की आवश्यकता नहीं',
        reason: 'उपयुक्त मौसम',
        color: 'text-green-600'
      };
    }
  };

  const irrigationAdvice = getIrrigationAdvice();

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="px-4 py-4 flex items-center">
          <button
            onClick={() => setCurrentScreen('home')}
            className="mr-4 p-2 rounded-full bg-sky-100 text-sky-600"
          >
            ←
          </button>
          <div className="flex items-center">
            <span className="text-2xl mr-3">🌤️</span>
            <div>
              <h1 className="text-xl font-bold text-gray-800">मौसम सलाह</h1>
              <p className="text-sm text-gray-600">Weather Advice</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        {/* Location */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <span className="text-xl mr-2">📍</span>
              <span className="font-medium text-gray-800">{location}</span>
            </div>
            <button className="text-blue-500 text-sm">बदलें</button>
          </div>
        </div>

        {/* Current Weather */}
        <div className="bg-gradient-to-r from-blue-500 to-sky-500 text-white rounded-xl p-6 mb-6">
          <div className="text-center">
            <div className="text-6xl mb-2">⛅</div>
            <h2 className="text-3xl font-bold mb-2">{currentWeather.temperature}°C</h2>
            <p className="text-blue-100 mb-4">{currentWeather.condition}</p>
            
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div className="text-center">
                <p className="text-blue-200">नमी</p>
                <p className="font-bold">{currentWeather.humidity}%</p>
              </div>
              <div className="text-center">
                <p className="text-blue-200">हवा</p>
                <p className="font-bold">{currentWeather.windSpeed} km/h</p>
              </div>
              <div className="text-center">
                <p className="text-blue-200">बारिश</p>
                <p className="font-bold">{currentWeather.rainfall} mm</p>
              </div>
            </div>
          </div>
        </div>

        {/* 5-Day Forecast */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">📅</span>
            5 दिन का मौसम
          </h3>
          
          <div className="space-y-3">
            {currentWeather.forecast.map((day, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <span className="text-2xl mr-3">{day.icon}</span>
                  <div>
                    <p className="font-medium text-gray-800">{day.date}</p>
                    <p className="text-sm text-gray-600">{day.condition}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-gray-800">{day.temp}°C</p>
                  {day.rainfall > 0 && (
                    <p className="text-sm text-blue-600">{day.rainfall}mm</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Irrigation Advice */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">💧</span>
            सिंचाई सलाह
          </h3>
          
          <div className="p-4 bg-blue-50 rounded-lg">
            <p className={`font-bold text-lg ${irrigationAdvice.color}`}>
              {irrigationAdvice.recommendation}
            </p>
            <p className="text-gray-600 mt-1">{irrigationAdvice.reason}</p>
            
            <div className="mt-3 text-sm text-gray-700">
              <p>• सुबह 6-8 बजे या शाम 5-7 बजे सिंचाई करें</p>
              <p>• ड्रिप इरिगेशन का उपयोग करें</p>
              <p>• मिट्टी की नमी जांचें</p>
            </div>
          </div>
        </div>

        {/* Weather-based Farming Advice */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">🌾</span>
            मौसम आधारित सलाह
          </h3>
          
          <div className="space-y-3">
            {getWeatherAdvice().map((advice, index) => (
              <div key={index} className="flex items-start p-3 bg-yellow-50 rounded-lg">
                <span className="text-yellow-600 mr-2">⚠️</span>
                <p className="text-yellow-800 text-sm">{advice}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Crop-specific Advice */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">🌱</span>
            फसल विशेष सलाह
          </h3>
          
          <div className="space-y-3">
            {getCropSpecificAdvice().map((advice, index) => (
              <div key={index} className="flex items-start p-3 bg-green-50 rounded-lg">
                <span className="text-green-600 mr-2">✓</span>
                <p className="text-green-800 text-sm">{advice}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Weather Alerts */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-20">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">🚨</span>
            मौसम चेतावनी
          </h3>
          
          <div className="p-4 bg-red-50 rounded-lg border-l-4 border-red-500">
            <div className="flex items-center mb-2">
              <span className="text-red-600 mr-2">⚠️</span>
              <p className="font-bold text-red-800">भारी बारिश की चेतावनी</p>
            </div>
            <p className="text-red-700 text-sm mb-2">
              अगले 48 घंटों में भारी बारिश की संभावना है।
            </p>
            <div className="text-sm text-red-600">
              <p>• फसलों की सुरक्षा करें</p>
              <p>• जल निकासी की व्यवस्था करें</p>
              <p>• कटी हुई फसल को सुरक्षित स्थान पर रखें</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WeatherAdvice;
