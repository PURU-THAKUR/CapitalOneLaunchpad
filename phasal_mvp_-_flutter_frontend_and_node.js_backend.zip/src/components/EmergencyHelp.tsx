import React, { useState } from 'react';
import { useMutation } from 'convex/react';
import { api } from '../../convex/_generated/api';

interface EmergencyHelpProps {
  setCurrentScreen: (screen: string) => void;
}

const EmergencyHelp: React.FC<EmergencyHelpProps> = ({ setCurrentScreen }) => {
  const [selectedEmergency, setSelectedEmergency] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const submitComplaint = useMutation(api.farming.submitComplaint);

  const emergencyTypes = [
    { id: 'flood', name: 'बाढ़', icon: '🌊', color: 'bg-blue-500' },
    { id: 'drought', name: 'सूखा', icon: '🏜️', color: 'bg-yellow-500' },
    { id: 'pest-attack', name: 'कीट आक्रमण', icon: '🐛', color: 'bg-red-500' },
    { id: 'disease-outbreak', name: 'रोग प्रकोप', icon: '🦠', color: 'bg-purple-500' },
    { id: 'hailstorm', name: 'ओलावृष्टि', icon: '🧊', color: 'bg-gray-500' },
    { id: 'fire', name: 'आग', icon: '🔥', color: 'bg-orange-500' }
  ];

  const emergencyContacts = [
    { name: 'कृषि विभाग हेल्पलाइन', number: '1800-180-1551', icon: '🏛️' },
    { name: 'किसान कॉल सेंटर', number: '1800-180-1551', icon: '📞' },
    { name: 'मौसम विभाग', number: '1800-180-1555', icon: '🌤️' },
    { name: 'आपातकाल सेवा', number: '112', icon: '🚨' }
  ];

  const handleSubmitEmergency = async () => {
    if (!selectedEmergency || !description || !location) {
      alert('कृपया सभी आवश्यक जानकारी भरें');
      return;
    }

    setIsSubmitting(true);
    try {
      await submitComplaint({
        title: `आपातकाल: ${emergencyTypes.find(e => e.id === selectedEmergency)?.name}`,
        description: `स्थान: ${location}\nविवरण: ${description}\nसंपर्क: ${contactNumber}`,
        category: 'emergency',
        priority: 'emergency'
      });
      
      alert('आपकी आपातकालीन रिपोर्ट सफलतापूर्वक भेज दी गई है। जल्द ही सहायता मिलेगी।');
      
      // Reset form
      setSelectedEmergency('');
      setLocation('');
      setDescription('');
      setContactNumber('');
    } catch (error) {
      alert('रिपोर्ट भेजने में समस्या हुई। कृपया फिर से कोशिश करें।');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="px-4 py-4 flex items-center">
          <button
            onClick={() => setCurrentScreen('home')}
            className="mr-4 p-2 rounded-full bg-red-100 text-red-600"
          >
            ←
          </button>
          <div className="flex items-center">
            <span className="text-2xl mr-3">🚨</span>
            <div>
              <h1 className="text-xl font-bold text-gray-800">आपातकालीन सहायता</h1>
              <p className="text-sm text-gray-600">Emergency Help</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        {/* Emergency Alert */}
        <div className="bg-red-500 text-white rounded-xl p-4 mb-6">
          <div className="flex items-center mb-2">
            <span className="text-2xl mr-3">⚠️</span>
            <h2 className="text-lg font-bold">तत्काल सहायता चाहिए?</h2>
          </div>
          <p className="text-red-100 mb-3">
            गंभीर आपातकाल में तुरंत 112 पर कॉल करें
          </p>
          <button 
            onClick={() => window.open('tel:112')}
            className="bg-white text-red-500 px-4 py-2 rounded-lg font-bold hover:bg-red-50 transition-colors"
          >
            📞 112 पर कॉल करें
          </button>
        </div>

        {/* Emergency Type Selection */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4">आपातकाल का प्रकार</h3>
          
          <div className="grid grid-cols-2 gap-3">
            {emergencyTypes.map((emergency) => (
              <button
                key={emergency.id}
                onClick={() => setSelectedEmergency(emergency.id)}
                className={`p-3 rounded-lg border-2 transition-all ${
                  selectedEmergency === emergency.id
                    ? 'border-red-500 bg-red-50'
                    : 'border-gray-200 bg-white'
                }`}
              >
                <div className="text-2xl mb-1">{emergency.icon}</div>
                <p className="text-sm font-medium text-gray-800">{emergency.name}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Emergency Report Form */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4">आपातकालीन रिपोर्ट</h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                स्थान (गांव/जिला) *
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="जैसे: रामपुर गांव, पटना"
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                समस्या का विवरण *
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="समस्या का विस्तृत विवरण दें..."
                rows={4}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                संपर्क नंबर
              </label>
              <input
                type="tel"
                value={contactNumber}
                onChange={(e) => setContactNumber(e.target.value)}
                placeholder="आपका मोबाइल नंबर"
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500"
              />
            </div>

            <button
              onClick={handleSubmitEmergency}
              disabled={isSubmitting}
              className="w-full bg-red-500 text-white py-3 rounded-lg font-bold hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isSubmitting ? 'भेजा जा रहा है...' : '🚨 आपातकालीन रिपोर्ट भेजें'}
            </button>
          </div>
        </div>

        {/* Emergency Contacts */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">📞</span>
            आपातकालीन संपर्क
          </h3>
          
          <div className="space-y-3">
            {emergencyContacts.map((contact, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <span className="text-xl mr-3">{contact.icon}</span>
                  <div>
                    <p className="font-medium text-gray-800">{contact.name}</p>
                    <p className="text-sm text-gray-600">{contact.number}</p>
                  </div>
                </div>
                <button
                  onClick={() => window.open(`tel:${contact.number}`)}
                  className="bg-green-500 text-white px-3 py-1 rounded-lg text-sm hover:bg-green-600 transition-colors"
                >
                  कॉल करें
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">⚡</span>
            त्वरित कार्य
          </h3>
          
          <div className="grid grid-cols-2 gap-3">
            <button className="p-3 bg-blue-50 rounded-lg text-center hover:bg-blue-100 transition-colors">
              <div className="text-2xl mb-1">🌊</div>
              <p className="text-sm font-medium text-blue-800">बाढ़ चेतावनी</p>
            </button>
            
            <button className="p-3 bg-yellow-50 rounded-lg text-center hover:bg-yellow-100 transition-colors">
              <div className="text-2xl mb-1">🌡️</div>
              <p className="text-sm font-medium text-yellow-800">मौसम अलर्ट</p>
            </button>
            
            <button className="p-3 bg-green-50 rounded-lg text-center hover:bg-green-100 transition-colors">
              <div className="text-2xl mb-1">🏥</div>
              <p className="text-sm font-medium text-green-800">पशु चिकित्सक</p>
            </button>
            
            <button className="p-3 bg-purple-50 rounded-lg text-center hover:bg-purple-100 transition-colors">
              <div className="text-2xl mb-1">💰</div>
              <p className="text-sm font-medium text-purple-800">बीमा क्लेम</p>
            </button>
          </div>
        </div>

        {/* Safety Tips */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-20">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">💡</span>
            सुरक्षा सुझाव
          </h3>
          
          <div className="space-y-3">
            <div className="p-3 bg-green-50 rounded-lg">
              <p className="font-medium text-green-800 mb-1">बाढ़ के समय</p>
              <p className="text-green-700 text-sm">
                • ऊंची जगह पर जाएं • बिजली के उपकरणों से दूर रहें • साफ पानी स्टोर करें
              </p>
            </div>
            
            <div className="p-3 bg-yellow-50 rounded-lg">
              <p className="font-medium text-yellow-800 mb-1">सूखे के समय</p>
              <p className="text-yellow-700 text-sm">
                • पानी की बचत करें • सूखा प्रतिरोधी फसल लगाएं • मल्चिंग का उपयोग करें
              </p>
            </div>
            
            <div className="p-3 bg-red-50 rounded-lg">
              <p className="font-medium text-red-800 mb-1">आग के समय</p>
              <p className="text-red-700 text-sm">
                • तुरंत 112 पर कॉल करें • हवा की दिशा के विपरीत भागें • धुआं सूंघने पर नाक-मुंह ढकें
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmergencyHelp;
