import React, { useState } from 'react';
import { useQuery } from 'convex/react';
import { api } from '../../convex/_generated/api';

interface MandiPricesProps {
  setCurrentScreen: (screen: string) => void;
}

const MandiPrices: React.FC<MandiPricesProps> = ({ setCurrentScreen }) => {
  const [selectedCrop, setSelectedCrop] = useState('Wheat');
  const [selectedState, setSelectedState] = useState('Bihar');
  
  // Mock data - in production, this would come from real APIs
  const mockPrices = [
    {
      cropName: 'Wheat',
      marketName: 'Patna',
      state: 'Bihar',
      district: 'Patna',
      minPrice: 2100,
      maxPrice: 2300,
      modalPrice: 2200,
      date: '2024-01-15',
      trend: 'up'
    },
    {
      cropName: 'Wheat',
      marketName: 'Darbhanga',
      state: 'Bihar',
      district: 'Darbhanga',
      minPrice: 2050,
      maxPrice: 2250,
      modalPrice: 2150,
      date: '2024-01-15',
      trend: 'stable'
    },
    {
      cropName: 'Rice',
      marketName: 'Patna',
      state: 'Bihar',
      district: 'Patna',
      minPrice: 3000,
      maxPrice: 3400,
      modalPrice: 3200,
      date: '2024-01-15',
      trend: 'up'
    },
    {
      cropName: 'Rice',
      marketName: 'Muzaffarpur',
      state: 'Bihar',
      district: 'Muzaffarpur',
      minPrice: 2950,
      maxPrice: 3350,
      modalPrice: 3150,
      date: '2024-01-15',
      trend: 'stable'
    },
    {
      cropName: 'Tomato',
      marketName: 'Patna',
      state: 'Bihar',
      district: 'Patna',
      minPrice: 1400,
      maxPrice: 1800,
      modalPrice: 1600,
      date: '2024-01-15',
      trend: 'down'
    }
  ];

  const crops = ['Wheat', 'Rice', 'Maize', 'Tomato', 'Potato', 'Onion', 'Cotton', 'Sugarcane'];
  const states = ['Bihar', 'Uttar Pradesh', 'Punjab', 'Haryana', 'Madhya Pradesh'];

  const filteredPrices = mockPrices.filter(price => 
    price.cropName === selectedCrop && price.state === selectedState
  );

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return '📈';
      case 'down': return '📉';
      default: return '➡️';
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'up': return 'text-green-600';
      case 'down': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getBestPrice = () => {
    if (filteredPrices.length === 0) return null;
    return filteredPrices.reduce((best, current) => 
      current.modalPrice > best.modalPrice ? current : best
    );
  };

  const bestPrice = getBestPrice();

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="px-4 py-4 flex items-center">
          <button
            onClick={() => setCurrentScreen('home')}
            className="mr-4 p-2 rounded-full bg-yellow-100 text-yellow-600"
          >
            ←
          </button>
          <div className="flex items-center">
            <span className="text-2xl mr-3">💰</span>
            <div>
              <h1 className="text-xl font-bold text-gray-800">मंडी भाव</h1>
              <p className="text-sm text-gray-600">Market Prices</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        {/* Best Price Alert */}
        {bestPrice && (
          <div className="bg-green-500 text-white rounded-xl p-4 mb-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">सबसे अच्छा भाव</p>
                <p className="text-xl font-bold">₹{bestPrice.modalPrice}/क्विंटल</p>
                <p className="text-green-100">{bestPrice.marketName}, {bestPrice.state}</p>
              </div>
              <div className="text-3xl">🏆</div>
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4">फसल और राज्य चुनें</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">फसल</label>
              <select
                value={selectedCrop}
                onChange={(e) => setSelectedCrop(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500"
              >
                {crops.map(crop => (
                  <option key={crop} value={crop}>
                    {crop === 'Wheat' ? 'गेहूं' :
                     crop === 'Rice' ? 'चावल' :
                     crop === 'Maize' ? 'मक्का' :
                     crop === 'Tomato' ? 'टमाटर' :
                     crop === 'Potato' ? 'आलू' :
                     crop === 'Onion' ? 'प्याज' :
                     crop === 'Cotton' ? 'कपास' :
                     crop === 'Sugarcane' ? 'गन्ना' : crop}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">राज्य</label>
              <select
                value={selectedState}
                onChange={(e) => setSelectedState(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500"
              >
                {states.map(state => (
                  <option key={state} value={state}>{state}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Price List */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">📊</span>
            आज के भाव
          </h3>

          {filteredPrices.length > 0 ? (
            <div className="space-y-3">
              {filteredPrices.map((price, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-bold text-gray-800">{price.marketName}</h4>
                    <div className="flex items-center">
                      <span className={`${getTrendColor(price.trend)} mr-1`}>
                        {getTrendIcon(price.trend)}
                      </span>
                      <span className={`text-sm font-medium ${getTrendColor(price.trend)}`}>
                        {price.trend === 'up' ? 'बढ़ रहा' : 
                         price.trend === 'down' ? 'गिर रहा' : 'स्थिर'}
                      </span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div className="text-center p-2 bg-red-50 rounded">
                      <p className="text-red-600 font-medium">न्यूनतम</p>
                      <p className="font-bold">₹{price.minPrice}</p>
                    </div>
                    <div className="text-center p-2 bg-green-50 rounded">
                      <p className="text-green-600 font-medium">मॉडल</p>
                      <p className="font-bold">₹{price.modalPrice}</p>
                    </div>
                    <div className="text-center p-2 bg-blue-50 rounded">
                      <p className="text-blue-600 font-medium">अधिकतम</p>
                      <p className="font-bold">₹{price.maxPrice}</p>
                    </div>
                  </div>
                  
                  <p className="text-xs text-gray-500 mt-2">
                    अपडेट: {new Date(price.date).toLocaleDateString('hi-IN')}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <span className="text-4xl mb-4 block">📈</span>
              <p className="text-gray-600">इस फसल के लिए डेटा उपलब्ध नहीं है</p>
              <p className="text-sm text-gray-500 mt-2">कृपया दूसरी फसल या राज्य चुनें</p>
            </div>
          )}
        </div>

        {/* Price Trends */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">📈</span>
            मूल्य पूर्वानुमान
          </h3>
          
          <div className="space-y-3">
            <div className="p-3 bg-green-50 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="font-medium text-green-800">अगले 7 दिन</span>
                <span className="text-green-600 font-bold">+5% वृद्धि</span>
              </div>
              <p className="text-sm text-green-700 mt-1">
                त्योहारी सीजन के कारण मांग बढ़ने की उम्मीद
              </p>
            </div>
            
            <div className="p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="font-medium text-blue-800">अगले 15 दिन</span>
                <span className="text-blue-600 font-bold">स्थिर रहेगा</span>
              </div>
              <p className="text-sm text-blue-700 mt-1">
                नई फसल आने तक भाव स्थिर रहने की संभावना
              </p>
            </div>
          </div>
        </div>

        {/* Selling Tips */}
        <div className="bg-white rounded-xl shadow-md p-4 mb-20">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center">
            <span className="mr-2">💡</span>
            बेचने के सुझाव
          </h3>
          
          <div className="space-y-3">
            <div className="flex items-start p-3 bg-yellow-50 rounded-lg">
              <span className="text-yellow-600 mr-2">💰</span>
              <div>
                <p className="font-medium text-yellow-800">सबसे अच्छा समय</p>
                <p className="text-yellow-700 text-sm">सुबह 10-12 बजे मंडी में सबसे अच्छे भाव मिलते हैं</p>
              </div>
            </div>
            
            <div className="flex items-start p-3 bg-blue-50 rounded-lg">
              <span className="text-blue-600 mr-2">📦</span>
              <div>
                <p className="font-medium text-blue-800">पैकेजिंग</p>
                <p className="text-blue-700 text-sm">साफ बोरियों में पैक करके ले जाएं</p>
              </div>
            </div>
            
            <div className="flex items-start p-3 bg-green-50 rounded-lg">
              <span className="text-green-600 mr-2">🚛</span>
              <div>
                <p className="font-medium text-green-800">परिवहन</p>
                <p className="text-green-700 text-sm">नजदीकी मंडी में बेचने से परिवहन लागत कम होगी</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MandiPrices;
