import React, { useState } from 'react';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../../convex/_generated/api';

interface ComplaintSystemProps {
  setCurrentScreen: (screen: string) => void;
}

const ComplaintSystem: React.FC<ComplaintSystemProps> = ({ setCurrentScreen }) => {
  const [activeTab, setActiveTab] = useState<'new' | 'track'>('new');
  const [complaintData, setComplaintData] = useState({
    title: '',
    description: '',
    category: '',
    priority: 'medium'
  });

  const complaints = useQuery(api.farming.getComplaints, {});
  const submitComplaint = useMutation(api.farming.submitComplaint);

  const categories = [
    { id: 'pest', name: 'कीट-पतंगे', icon: '🐛' },
    { id: 'disease', name: 'फसल रोग', icon: '🦠' },
    { id: 'weather', name: 'मौसम समस्या', icon: '🌤️' },
    { id: 'market', name: 'मंडी समस्या', icon: '💰' },
    { id: 'scheme', name: 'सरकारी योजना', icon: '🏛️' },
    { id: 'irrigation', name: 'सिंचाई समस्या', icon: '💧' },
    { id: 'fertilizer', name: 'खाद-बीज', icon: '🌱' },
    { id: 'other', name: 'अन्य', icon: '📝' }
  ];

  const priorities = [
    { id: 'low', name: 'कम', color: 'text-green-600' },
    { id: 'medium', name: 'मध्यम', color: 'text-yellow-600' },
    { id: 'high', name: 'उच्च', color: 'text-red-600' }
  ];

  const handleSubmitComplaint = async () => {
    if (!complaintData.title || !complaintData.description || !complaintData.category) {
      alert('कृपया सभी आवश्यक जानकारी भरें');
      return;
    }

    try {
      await submitComplaint(complaintData);
      alert('आपकी शिकायत सफलतापूर्वक दर्ज हो गई है। आपको जल्द ही जवाब मिलेगा।');
      
      // Reset form
      setComplaintData({
        title: '',
        description: '',
        category: '',
        priority: 'medium'
      });
    } catch (error) {
      alert('शिकायत दर्ज करने में समस्या हुई। कृपया फिर से कोशिश करें।');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'text-red-600 bg-red-50';
      case 'in_progress': return 'text-yellow-600 bg-yellow-50';
      case 'resolved': return 'text-green-600 bg-green-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'open': return 'खुली';
      case 'in_progress': return 'प्रगति में';
      case 'resolved': return 'हल हो गई';
      default: return 'अज्ञात';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="px-4 py-4 flex items-center">
          <button
            onClick={() => setCurrentScreen('home')}
            className="mr-4 p-2 rounded-full bg-orange-100 text-orange-600"
          >
            ←
          </button>
          <div className="flex items-center">
            <span className="text-2xl mr-3">📝</span>
            <div>
              <h1 className="text-xl font-bold text-gray-800">शिकायत प्रणाली</h1>
              <p className="text-sm text-gray-600">Complaint System</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white border-b border-gray-200">
        <div className="px-4">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('new')}
              className={`py-4 px-2 border-b-2 font-medium text-sm ${
                activeTab === 'new'
                  ? 'border-orange-500 text-orange-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              नई शिकायत
            </button>
            <button
              onClick={() => setActiveTab('track')}
              className={`py-4 px-2 border-b-2 font-medium text-sm ${
                activeTab === 'track'
                  ? 'border-orange-500 text-orange-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              शिकायत ट्रैक करें
            </button>
          </div>
        </div>
      </div>

      <div className="p-4">
        {activeTab === 'new' ? (
          <>
            {/* New Complaint Form */}
            <div className="bg-white rounded-xl shadow-md p-4 mb-6">
              <h3 className="font-bold text-gray-800 mb-4">नई शिकायत दर्ज करें</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    शिकायत का विषय *
                  </label>
                  <input
                    type="text"
                    value={complaintData.title}
                    onChange={(e) => setComplaintData({...complaintData, title: e.target.value})}
                    placeholder="जैसे: फसल में कीड़े लगे हैं"
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    श्रेणी *
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {categories.map((category) => (
                      <button
                        key={category.id}
                        onClick={() => setComplaintData({...complaintData, category: category.id})}
                        className={`p-2 rounded-lg border text-left transition-all ${
                          complaintData.category === category.id
                            ? 'border-orange-500 bg-orange-50'
                            : 'border-gray-200 bg-white'
                        }`}
                      >
                        <span className="mr-2">{category.icon}</span>
                        <span className="text-sm">{category.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    प्राथमिकता
                  </label>
                  <div className="flex space-x-4">
                    {priorities.map((priority) => (
                      <button
                        key={priority.id}
                        onClick={() => setComplaintData({...complaintData, priority: priority.id})}
                        className={`px-3 py-2 rounded-lg border text-sm transition-all ${
                          complaintData.priority === priority.id
                            ? 'border-orange-500 bg-orange-50'
                            : 'border-gray-200 bg-white'
                        }`}
                      >
                        <span className={priority.color}>{priority.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    विस्तृत विवरण *
                  </label>
                  <textarea
                    value={complaintData.description}
                    onChange={(e) => setComplaintData({...complaintData, description: e.target.value})}
                    placeholder="समस्या का विस्तृत विवरण दें..."
                    rows={4}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <button
                  onClick={handleSubmitComplaint}
                  className="w-full bg-orange-500 text-white py-3 rounded-lg font-medium hover:bg-orange-600 transition-colors"
                >
                  शिकायत दर्ज करें
                </button>
              </div>
            </div>

            {/* Help Section */}
            <div className="bg-white rounded-xl shadow-md p-4 mb-20">
              <h3 className="font-bold text-gray-800 mb-4 flex items-center">
                <span className="mr-2">💡</span>
                शिकायत दर्ज करने के सुझाव
              </h3>
              
              <div className="space-y-3">
                <div className="flex items-start p-3 bg-blue-50 rounded-lg">
                  <span className="text-blue-600 mr-2">📝</span>
                  <div>
                    <p className="font-medium text-blue-800">स्पष्ट विवरण दें</p>
                    <p className="text-blue-700 text-sm">समस्या का विस्तृत और स्पष्ट विवरण दें</p>
                  </div>
                </div>
                
                <div className="flex items-start p-3 bg-green-50 rounded-lg">
                  <span className="text-green-600 mr-2">📸</span>
                  <div>
                    <p className="font-medium text-green-800">फोटो संलग्न करें</p>
                    <p className="text-green-700 text-sm">यदि संभव हो तो समस्या की फोटो भी भेजें</p>
                  </div>
                </div>
                
                <div className="flex items-start p-3 bg-yellow-50 rounded-lg">
                  <span className="text-yellow-600 mr-2">⏰</span>
                  <div>
                    <p className="font-medium text-yellow-800">धैर्य रखें</p>
                    <p className="text-yellow-700 text-sm">जवाब आने में 2-3 दिन का समय लग सकता है</p>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <>
            {/* Track Complaints */}
            <div className="bg-white rounded-xl shadow-md p-4 mb-6">
              <h3 className="font-bold text-gray-800 mb-4">आपकी शिकायतें</h3>
              
              {complaints && complaints.length > 0 ? (
                <div className="space-y-4">
                  {complaints.map((complaint) => (
                    <div key={complaint._id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-bold text-gray-800">{complaint.title}</h4>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(complaint.status)}`}>
                          {getStatusText(complaint.status)}
                        </span>
                      </div>
                      
                      <p className="text-gray-600 text-sm mb-2">{complaint.description}</p>
                      
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>
                          श्रेणी: {categories.find(c => c.id === complaint.category)?.name || complaint.category}
                        </span>
                        <span>
                          {new Date(complaint.timestamp).toLocaleDateString('hi-IN')}
                        </span>
                      </div>
                      
                      {complaint.response && (
                        <div className="mt-3 p-3 bg-green-50 rounded-lg">
                          <p className="font-medium text-green-800 text-sm">जवाब:</p>
                          <p className="text-green-700 text-sm">{complaint.response}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <span className="text-4xl mb-4 block">📋</span>
                  <p className="text-gray-600">अभी तक कोई शिकायत दर्ज नहीं की गई है</p>
                  <button
                    onClick={() => setActiveTab('new')}
                    className="mt-4 bg-orange-500 text-white px-4 py-2 rounded-lg text-sm hover:bg-orange-600 transition-colors"
                  >
                    पहली शिकायत दर्ज करें
                  </button>
                </div>
              )}
            </div>

            {/* Contact Information */}
            <div className="bg-white rounded-xl shadow-md p-4 mb-20">
              <h3 className="font-bold text-gray-800 mb-4 flex items-center">
                <span className="mr-2">📞</span>
                संपर्क जानकारी
              </h3>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <span className="text-xl mr-3">🏛️</span>
                    <div>
                      <p className="font-medium text-gray-800">कृषि विभाग</p>
                      <p className="text-sm text-gray-600">1800-180-1551</p>
                    </div>
                  </div>
                  <button
                    onClick={() => window.open('tel:1800-180-1551')}
                    className="bg-green-500 text-white px-3 py-1 rounded-lg text-sm hover:bg-green-600 transition-colors"
                  >
                    कॉल करें
                  </button>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center">
                    <span className="text-xl mr-3">📧</span>
                    <div>
                      <p className="font-medium text-gray-800">ईमेल सहायता</p>
                      <p className="text-sm text-gray-600">support@agriculture.gov.in</p>
                    </div>
                  </div>
                  <button
                    onClick={() => window.open('mailto:support@agriculture.gov.in')}
                    className="bg-blue-500 text-white px-3 py-1 rounded-lg text-sm hover:bg-blue-600 transition-colors"
                  >
                    ईमेल करें
                  </button>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default ComplaintSystem;
