// Translation utility for PHASAL app
export interface Translation {
  [key: string]: string | Translation;
}

export const translations: Record<string, Translation> = {
  english: {
    // App Name and Common
    appName: 'PHASAL',
    tagline: 'AI-Powered Farming Assistant',
    back: 'Back',
    home: 'Home',
    loading: 'Loading...',
    error: 'Error',
    success: 'Success',
    submit: 'Submit',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    edit: 'Edit',
    view: 'View',
    search: 'Search',
    filter: 'Filter',
    
    // Home Screen
    welcome: 'Welcome Farmer! 🙏',
    welcomeMessage: 'All facilities are available here to help with your farming.',
    online: 'Online',
    location: 'Location: Patna, Bihar',
    temperature: '28°C',
    
    // Features
    cropCalendar: 'Crop Calendar',
    cropCalendarDesc: 'Sowing and harvesting time',
    soilAnalysis: 'Soil Analysis',
    soilAnalysisDesc: 'Soil testing and recommendations',
    cropHealth: 'Crop Health',
    cropHealthDesc: 'Disease and pest identification',
    weatherAdvice: 'Weather Advice',
    weatherAdviceDesc: 'Weather-based recommendations',
    mandiPrices: 'Market Prices',
    mandiPricesDesc: 'Live market rates',
    aiAssistant: 'AI Assistant',
    aiAssistantDesc: 'Local language support',
    wasteUpcycling: 'Waste Upcycling',
    wasteUpcyclingDesc: 'Crop waste utilization',
    emergencyHelp: 'Emergency Help',
    emergencyHelpDesc: 'Immediate assistance',
    complaintSystem: 'Complaint System',
    complaintSystemDesc: 'File complaints',
    farmerNetwork: 'Farmer Network',
    farmerNetworkDesc: 'Farmer community',
    harvestPlanner: 'Harvest Planner',
    harvestPlannerDesc: 'Harvesting and transport',
    govSchemes: 'Government Schemes',
    govSchemesDesc: 'Fill scheme forms',
    
    // AI Chatbot
    chatWelcome: 'Hello! I am your AI farming assistant. You can ask me about farming, weather, market prices, or agricultural schemes. 🌾',
    askQuestion: 'Type your question here...',
    voiceInput: 'Voice input feature coming soon!',
    quickQuestions: 'Quick Questions',
    todayWeather: 'How is today\'s weather?',
    wheatPrice: 'What is wheat price?',
    kharifSowing: 'When to sow kharif crops?',
    pestProblem: 'Pests in crops',
    irrigationTime: 'When to irrigate?',
    govSchemesList: 'Tell about government schemes',
    
    // Weather
    currentSeason: 'Current Season',
    month: 'Month',
    irrigationAdvice: 'Irrigation Advice',
    weatherBasedAdvice: 'Weather-based Advice',
    cropSpecificAdvice: 'Crop-specific Advice',
    weatherAlert: 'Weather Alert',
    heavyRainWarning: 'Heavy Rain Warning',
    
    // Market Prices
    bestPrice: 'Best Price',
    selectCropState: 'Select Crop and State',
    crop: 'Crop',
    state: 'State',
    todayPrices: 'Today\'s Prices',
    minimum: 'Minimum',
    modal: 'Modal',
    maximum: 'Maximum',
    updated: 'Updated',
    priceForecast: 'Price Forecast',
    sellingTips: 'Selling Tips',
    
    // Emergency
    emergencyAlert: 'Need immediate help?',
    call112: 'Call 112 immediately for serious emergencies',
    emergencyType: 'Emergency Type',
    emergencyReport: 'Emergency Report',
    locationRequired: 'Location (Village/District) *',
    problemDescription: 'Problem Description *',
    contactNumber: 'Contact Number',
    submitEmergencyReport: '🚨 Submit Emergency Report',
    
    // Common Messages
    fillAllFields: 'Please fill all required information',
    submittedSuccessfully: 'Submitted successfully',
    somethingWentWrong: 'Something went wrong. Please try again.',
  },
  
  hindi: {
    // App Name and Common
    appName: 'PHASAL',
    tagline: 'AI-संचालित कृषि सहायक',
    back: 'वापस',
    home: 'होम',
    loading: 'लोड हो रहा है...',
    error: 'त्रुटि',
    success: 'सफलता',
    submit: 'जमा करें',
    cancel: 'रद्द करें',
    save: 'सेव करें',
    delete: 'हटाएं',
    edit: 'संपादित करें',
    view: 'देखें',
    search: 'खोजें',
    filter: 'फिल्टर',
    
    // Home Screen
    welcome: 'नमस्ते किसान भाई! 🙏',
    welcomeMessage: 'आपकी खेती में मदद के लिए सभी सुविधाएं यहां उपलब्ध हैं।',
    online: 'ऑनलाइन',
    location: 'स्थान: पटना, बिहार',
    temperature: '28°C',
    
    // Features
    cropCalendar: 'फसल कैलेंडर',
    cropCalendarDesc: 'बुआई और कटाई का समय',
    soilAnalysis: 'मिट्टी विश्लेषण',
    soilAnalysisDesc: 'मिट्टी की जांच और सुझाव',
    cropHealth: 'फसल स्वास्थ्य',
    cropHealthDesc: 'रोग और कीट की पहचान',
    weatherAdvice: 'मौसम सलाह',
    weatherAdviceDesc: 'मौसम आधारित सुझाव',
    mandiPrices: 'मंडी भाव',
    mandiPricesDesc: 'लाइव मार्केट रेट',
    aiAssistant: 'AI सहायक',
    aiAssistantDesc: 'स्थानीय भाषा में सहायता',
    wasteUpcycling: 'अपशिष्ट उपयोग',
    wasteUpcyclingDesc: 'फसल अपशिष्ट का उपयोग',
    emergencyHelp: 'आपातकालीन सहायता',
    emergencyHelpDesc: 'तत्काल सहायता',
    complaintSystem: 'शिकायत प्रणाली',
    complaintSystemDesc: 'शिकायत दर्ज करें',
    farmerNetwork: 'किसान नेटवर्क',
    farmerNetworkDesc: 'किसान समुदाय',
    harvestPlanner: 'फसल योजनाकार',
    harvestPlannerDesc: 'कटाई और परिवहन',
    govSchemes: 'सरकारी योजनाएं',
    govSchemesDesc: 'योजना फॉर्म भरें',
    
    // AI Chatbot
    chatWelcome: 'नमस्ते! मैं आपका AI कृषि सहायक हूं। आप मुझसे खेती, मौसम, मंडी भाव, या कृषि योजनाओं के बारे में पूछ सकते हैं। 🌾',
    askQuestion: 'अपना सवाल यहाँ लिखें...',
    voiceInput: 'Voice input feature coming soon!',
    quickQuestions: 'त्वरित प्रश्न',
    todayWeather: 'आज का मौसम कैसा है?',
    wheatPrice: 'गेहूं का भाव क्या है?',
    kharifSowing: 'खरीफ की फसल कब बोएं?',
    pestProblem: 'फसल में कीड़े लगे हैं',
    irrigationTime: 'सिंचाई कब करें?',
    govSchemesList: 'सरकारी योजनाएं बताएं',
    
    // Weather
    currentSeason: 'वर्तमान सीजन',
    month: 'महीना',
    irrigationAdvice: 'सिंचाई सलाह',
    weatherBasedAdvice: 'मौसम आधारित सलाह',
    cropSpecificAdvice: 'फसल विशेष सलाह',
    weatherAlert: 'मौसम चेतावनी',
    heavyRainWarning: 'भारी बारिश की चेतावनी',
    
    // Market Prices
    bestPrice: 'सबसे अच्छा भाव',
    selectCropState: 'फसल और राज्य चुनें',
    crop: 'फसल',
    state: 'राज्य',
    todayPrices: 'आज के भाव',
    minimum: 'न्यूनतम',
    modal: 'मॉडल',
    maximum: 'अधिकतम',
    updated: 'अपडेट',
    priceForecast: 'मूल्य पूर्वानुमान',
    sellingTips: 'बेचने के सुझाव',
    
    // Emergency
    emergencyAlert: 'तत्काल सहायता चाहिए?',
    call112: 'गंभीर आपातकाल में तुरंत 112 पर कॉल करें',
    emergencyType: 'आपातकाल का प्रकार',
    emergencyReport: 'आपातकालीन रिपोर्ट',
    locationRequired: 'स्थान (गांव/जिला) *',
    problemDescription: 'समस्या का विवरण *',
    contactNumber: 'संपर्क नंबर',
    submitEmergencyReport: '🚨 आपातकालीन रिपोर्ट भेजें',
    
    // Common Messages
    fillAllFields: 'कृपया सभी आवश्यक जानकारी भरें',
    submittedSuccessfully: 'सफलतापूर्वक जमा हो गया',
    somethingWentWrong: 'कुछ गलत हुआ है। कृपया फिर से कोशिश करें।',
  },
  
  spanish: {
    // App Name and Common
    appName: 'PHASAL',
    tagline: 'Asistente Agrícola con IA',
    back: 'Atrás',
    home: 'Inicio',
    loading: 'Cargando...',
    error: 'Error',
    success: 'Éxito',
    submit: 'Enviar',
    cancel: 'Cancelar',
    save: 'Guardar',
    delete: 'Eliminar',
    edit: 'Editar',
    view: 'Ver',
    search: 'Buscar',
    filter: 'Filtrar',
    
    // Home Screen
    welcome: '¡Bienvenido Agricultor! 🙏',
    welcomeMessage: 'Todas las facilidades están disponibles aquí para ayudar con su agricultura.',
    online: 'En línea',
    location: 'Ubicación: Patna, Bihar',
    temperature: '28°C',
    
    // Features
    cropCalendar: 'Calendario de Cultivos',
    cropCalendarDesc: 'Tiempo de siembra y cosecha',
    soilAnalysis: 'Análisis de Suelo',
    soilAnalysisDesc: 'Pruebas de suelo y recomendaciones',
    cropHealth: 'Salud de Cultivos',
    cropHealthDesc: 'Identificación de enfermedades y plagas',
    weatherAdvice: 'Consejos Meteorológicos',
    weatherAdviceDesc: 'Recomendaciones basadas en el clima',
    mandiPrices: 'Precios de Mercado',
    mandiPricesDesc: 'Tarifas de mercado en vivo',
    aiAssistant: 'Asistente IA',
    aiAssistantDesc: 'Soporte en idioma local',
    wasteUpcycling: 'Reciclaje de Residuos',
    wasteUpcyclingDesc: 'Utilización de residuos de cultivos',
    emergencyHelp: 'Ayuda de Emergencia',
    emergencyHelpDesc: 'Asistencia inmediata',
    complaintSystem: 'Sistema de Quejas',
    complaintSystemDesc: 'Presentar quejas',
    farmerNetwork: 'Red de Agricultores',
    farmerNetworkDesc: 'Comunidad de agricultores',
    harvestPlanner: 'Planificador de Cosecha',
    harvestPlannerDesc: 'Cosecha y transporte',
    govSchemes: 'Esquemas Gubernamentales',
    govSchemesDesc: 'Llenar formularios de esquemas',
    
    // AI Chatbot
    chatWelcome: '¡Hola! Soy tu asistente agrícola de IA. Puedes preguntarme sobre agricultura, clima, precios de mercado o esquemas agrícolas. 🌾',
    askQuestion: 'Escribe tu pregunta aquí...',
    voiceInput: '¡La función de entrada de voz estará disponible pronto!',
    quickQuestions: 'Preguntas Rápidas',
    todayWeather: '¿Cómo está el clima hoy?',
    wheatPrice: '¿Cuál es el precio del trigo?',
    kharifSowing: '¿Cuándo sembrar cultivos kharif?',
    pestProblem: 'Plagas en cultivos',
    irrigationTime: '¿Cuándo regar?',
    govSchemesList: 'Cuéntame sobre esquemas gubernamentales',
    
    // Common Messages
    fillAllFields: 'Por favor complete toda la información requerida',
    submittedSuccessfully: 'Enviado exitosamente',
    somethingWentWrong: 'Algo salió mal. Por favor intente de nuevo.',
  },
  
  // Add more languages as needed...
  bhojpuri: {
    appName: 'PHASAL',
    tagline: 'AI से चलल खेती सहायक',
    welcome: 'नमस्कार किसान भाई! 🙏',
    welcomeMessage: 'रउआ के खेती में मदद खातिर सब सुविधा यहाँ उपलब्ध बा।',
    // Add more Bhojpuri translations...
  }
};

export const getTranslation = (language: string, key: string): string => {
  const keys = key.split('.');
  let value: any = translations[language] || translations.english;
  
  for (const k of keys) {
    value = value?.[k];
    if (value === undefined) {
      // Fallback to English if translation not found
      value = translations.english;
      for (const fallbackKey of keys) {
        value = value?.[fallbackKey];
        if (value === undefined) {
          return key; // Return key if no translation found
        }
      }
      break;
    }
  }
  
  return typeof value === 'string' ? value : key;
};

export const t = (language: string, key: string): string => {
  return getTranslation(language, key);
};
