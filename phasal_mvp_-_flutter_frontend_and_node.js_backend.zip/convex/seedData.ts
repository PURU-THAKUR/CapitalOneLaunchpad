import { mutation } from "./_generated/server";
import { v } from "convex/values";

export const seedMandiPrices = mutation({
  args: {},
  handler: async (ctx) => {
    const prices = [
      {
        cropName: "Wheat",
        marketName: "Patna",
        state: "Bihar",
        district: "Patna",
        minPrice: 2100,
        maxPrice: 2300,
        modalPrice: 2200,
        date: "2024-01-15",
        trend: "up"
      },
      {
        cropName: "Rice",
        marketName: "Patna",
        state: "Bihar", 
        district: "Patna",
        minPrice: 3000,
        maxPrice: 3400,
        modalPrice: 3200,
        date: "2024-01-15",
        trend: "stable"
      },
      {
        cropName: "Tomato",
        marketName: "Muzaffarpur",
        state: "Bihar",
        district: "Muzaffarpur",
        minPrice: 1400,
        maxPrice: 1800,
        modalPrice: 1600,
        date: "2024-01-15",
        trend: "down"
      }
    ];

    for (const price of prices) {
      await ctx.db.insert("mandiPrices", price);
    }
  },
});

export const seedCropCalendar = mutation({
  args: {},
  handler: async (ctx) => {
    const crops = [
      {
        cropName: "Wheat",
        region: "North India",
        sowingStart: "November",
        sowingEnd: "December",
        harvestStart: "April",
        harvestEnd: "May",
        duration: 120,
        soilType: ["Alluvial", "Black", "Red"],
        waterRequirement: "Medium",
        fertilizers: ["Urea", "DAP", "MOP"]
      },
      {
        cropName: "Rice",
        region: "North India",
        sowingStart: "June",
        sowingEnd: "July",
        harvestStart: "October",
        harvestEnd: "November",
        duration: 120,
        soilType: ["Alluvial", "Clay"],
        waterRequirement: "High",
        fertilizers: ["Urea", "DAP", "Zinc Sulphate"]
      }
    ];

    for (const crop of crops) {
      await ctx.db.insert("cropCalendar", crop);
    }
  },
});

export const seedSchemes = mutation({
  args: {},
  handler: async (ctx) => {
    const schemes = [
      {
        name: "PM-KISAN Samman Nidhi",
        description: "Direct income support to farmers",
        eligibility: ["Small and marginal farmers", "Land ownership required"],
        benefits: "₹6000 per year in 3 installments",
        applicationProcess: "Online registration on PM-KISAN portal",
        documents: ["Aadhaar Card", "Land Records", "Bank Account"],
        category: "Income Support",
        state: "All India"
      },
      {
        name: "Pradhan Mantri Fasal Bima Yojana",
        description: "Crop insurance scheme",
        eligibility: ["All farmers", "Sharecroppers included"],
        benefits: "Crop loss compensation up to sum insured",
        applicationProcess: "Through banks or insurance companies",
        documents: ["Aadhaar Card", "Land Records", "Sowing Certificate"],
        category: "Insurance",
        state: "All India"
      }
    ];

    for (const scheme of schemes) {
      await ctx.db.insert("schemes", scheme);
    }
  },
});
