import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  farmers: defineTable({
    name: v.string(),
    phone: v.optional(v.string()),
    location: v.optional(v.string()),
    farmSize: v.optional(v.number()),
    soilType: v.optional(v.string()),
    preferredLanguage: v.optional(v.string()),
    crops: v.optional(v.array(v.string())),
  }),
  
  cropAnalysis: defineTable({
    farmerId: v.optional(v.id("farmers")),
    imageId: v.optional(v.id("_storage")),
    analysisType: v.string(), // "disease", "pest", "nutrient", "soil"
    cropType: v.optional(v.string()),
    diagnosis: v.string(),
    treatment: v.string(),
    confidence: v.number(),
    timestamp: v.number(),
  }).index("by_farmer", ["farmerId"]),
  
  mandiPrices: defineTable({
    cropName: v.string(),
    marketName: v.string(),
    state: v.string(),
    district: v.string(),
    minPrice: v.number(),
    maxPrice: v.number(),
    modalPrice: v.number(),
    date: v.string(),
    trend: v.string(), // "up", "down", "stable"
  }).index("by_crop_and_market", ["cropName", "marketName"]),
  
  weatherData: defineTable({
    location: v.string(),
    temperature: v.number(),
    humidity: v.number(),
    rainfall: v.number(),
    windSpeed: v.number(),
    forecast: v.array(v.object({
      date: v.string(),
      temp: v.number(),
      condition: v.string(),
      rainfall: v.number(),
    })),
    timestamp: v.number(),
  }).index("by_location", ["location"]),
  
  cropCalendar: defineTable({
    cropName: v.string(),
    region: v.string(),
    sowingStart: v.string(),
    sowingEnd: v.string(),
    harvestStart: v.string(),
    harvestEnd: v.string(),
    duration: v.number(), // days
    soilType: v.array(v.string()),
    waterRequirement: v.string(),
    fertilizers: v.array(v.string()),
  }).index("by_crop_and_region", ["cropName", "region"]),
  
  complaints: defineTable({
    farmerId: v.optional(v.id("farmers")),
    title: v.string(),
    description: v.string(),
    category: v.string(), // "pest", "disease", "weather", "market", "scheme"
    status: v.string(), // "open", "in_progress", "resolved"
    priority: v.string(), // "low", "medium", "high", "emergency"
    assignedOfficer: v.optional(v.string()),
    response: v.optional(v.string()),
    timestamp: v.number(),
  }).index("by_farmer", ["farmerId"]).index("by_status", ["status"]),
  
  chatMessages: defineTable({
    farmerId: v.optional(v.id("farmers")),
    message: v.string(),
    response: v.string(),
    language: v.string(),
    timestamp: v.number(),
  }).index("by_farmer", ["farmerId"]),
  
  schemes: defineTable({
    name: v.string(),
    description: v.string(),
    eligibility: v.array(v.string()),
    benefits: v.string(),
    applicationProcess: v.string(),
    documents: v.array(v.string()),
    deadline: v.optional(v.string()),
    category: v.string(),
    state: v.optional(v.string()),
  }).index("by_category", ["category"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
