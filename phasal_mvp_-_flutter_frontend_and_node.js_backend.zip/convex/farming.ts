import { query, mutation, action, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { internal } from "./_generated/api";

// Crop Analysis Functions
export const analyzeCropImage = action({
  args: {
    imageId: v.id("_storage"),
    cropType: v.optional(v.string()),
    farmerId: v.optional(v.id("farmers")),
  },
  handler: async (ctx, args) => {
    // Mock AI analysis - in production, integrate with Gemini Vision API
    const mockAnalysis = {
      analysisType: "disease",
      diagnosis: "Leaf Blight detected in wheat crop",
      treatment: "Apply Mancozeb fungicide (2g/L water). Spray in evening. Repeat after 7 days if needed.",
      confidence: 0.85,
      recommendations: [
        "Remove affected leaves immediately",
        "Improve air circulation between plants",
        "Avoid overhead watering",
        "Monitor for 7-10 days"
      ]
    };

    // Store analysis result
    await ctx.runMutation(internal.farming.storeCropAnalysis, {
      farmerId: args.farmerId,
      imageId: args.imageId,
      analysisType: mockAnalysis.analysisType,
      cropType: args.cropType || "wheat",
      diagnosis: mockAnalysis.diagnosis,
      treatment: mockAnalysis.treatment,
      confidence: mockAnalysis.confidence,
    });

    return mockAnalysis;
  },
});

export const storeCropAnalysis = internalMutation({
  args: {
    farmerId: v.optional(v.id("farmers")),
    imageId: v.optional(v.id("_storage")),
    analysisType: v.string(),
    cropType: v.string(),
    diagnosis: v.string(),
    treatment: v.string(),
    confidence: v.number(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("cropAnalysis", {
      ...args,
      timestamp: Date.now(),
    });
  },
});

// Mandi Prices Functions
export const getMandiPrices = query({
  args: {
    cropName: v.optional(v.string()),
    state: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    if (args.cropName) {
      const prices = await ctx.db
        .query("mandiPrices")
        .withIndex("by_crop_and_market", (q) => 
          q.eq("cropName", args.cropName!)
        )
        .take(20);
      return prices;
    }
    
    const prices = await ctx.db.query("mandiPrices").take(20);
    return prices;
  },
});

export const updateMandiPrices = mutation({
  args: {
    prices: v.array(v.object({
      cropName: v.string(),
      marketName: v.string(),
      state: v.string(),
      district: v.string(),
      minPrice: v.number(),
      maxPrice: v.number(),
      modalPrice: v.number(),
      date: v.string(),
      trend: v.string(),
    })),
  },
  handler: async (ctx, args) => {
    for (const price of args.prices) {
      await ctx.db.insert("mandiPrices", price);
    }
  },
});

// Weather Functions
export const getWeatherData = query({
  args: {
    location: v.string(),
  },
  handler: async (ctx, args) => {
    const weather = await ctx.db
      .query("weatherData")
      .withIndex("by_location", (q) => q.eq("location", args.location))
      .order("desc")
      .first();
    
    return weather;
  },
});

export const updateWeatherData = mutation({
  args: {
    location: v.string(),
    temperature: v.number(),
    humidity: v.number(),
    rainfall: v.number(),
    windSpeed: v.number(),
    forecast: v.array(v.object({
      date: v.string(),
      temp: v.number(),
      condition: v.string(),
      rainfall: v.number(),
    })),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("weatherData", {
      ...args,
      timestamp: Date.now(),
    });
  },
});

// Crop Calendar Functions
export const getCropCalendar = query({
  args: {
    cropName: v.optional(v.string()),
    region: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    if (args.cropName && args.region) {
      return await ctx.db
        .query("cropCalendar")
        .withIndex("by_crop_and_region", (q) => 
          q.eq("cropName", args.cropName!).eq("region", args.region!)
        )
        .collect();
    }
    
    return await ctx.db.query("cropCalendar").collect();
  },
});

// Chat Functions
export const sendChatMessage = action({
  args: {
    message: v.string(),
    language: v.string(),
    farmerId: v.optional(v.id("farmers")),
  },
  handler: async (ctx, args) => {
    // Mock AI response - integrate with Gemini API for production
    const responses = {
      "weather": "आज का मौसम अच्छा है। तापमान 28°C है। हल्की बारिश की संभावना है।",
      "price": "आज गेहूं का भाव ₹2200 प्रति क्विंटल है। कल से बढ़ने की उम्मीद है।",
      "disease": "पत्तियों पर धब्बे दिख रहे हैं। यह फंगल इन्फेक्शन हो सकता है। मैंकोजेब का छिड़काव करें।",
      "fertilizer": "इस समय यूरिया और DAP का उपयोग करें। 50 किलो प्रति एकड़।",
    };

    const message = args.message.toLowerCase();
    let response = "मैं आपकी मदद करने की कोशिश कर रहा हूं। कृपया अपना सवाल स्पष्ट करें।";

    if (message.includes("मौसम") || message.includes("weather")) {
      response = responses.weather;
    } else if (message.includes("भाव") || message.includes("price")) {
      response = responses.price;
    } else if (message.includes("बीमारी") || message.includes("disease")) {
      response = responses.disease;
    } else if (message.includes("खाद") || message.includes("fertilizer")) {
      response = responses.fertilizer;
    }

    // Store chat message
    await ctx.runMutation(internal.farming.storeChatMessage, {
      farmerId: args.farmerId,
      message: args.message,
      response,
      language: args.language,
    });

    return { response };
  },
});

export const storeChatMessage = internalMutation({
  args: {
    farmerId: v.optional(v.id("farmers")),
    message: v.string(),
    response: v.string(),
    language: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("chatMessages", {
      ...args,
      timestamp: Date.now(),
    });
  },
});

// Complaints Functions
export const submitComplaint = mutation({
  args: {
    farmerId: v.optional(v.id("farmers")),
    title: v.string(),
    description: v.string(),
    category: v.string(),
    priority: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("complaints", {
      ...args,
      status: "open",
      timestamp: Date.now(),
    });
  },
});

export const getComplaints = query({
  args: {
    farmerId: v.optional(v.id("farmers")),
    status: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    if (args.farmerId) {
      return await ctx.db
        .query("complaints")
        .withIndex("by_farmer", (q) => q.eq("farmerId", args.farmerId))
        .order("desc")
        .take(50);
    }
    
    if (args.status) {
      return await ctx.db
        .query("complaints")
        .withIndex("by_status", (q) => q.eq("status", args.status!))
        .order("desc")
        .take(50);
    }
    
    return await ctx.db.query("complaints").order("desc").take(50);
  },
});

// Schemes Functions
export const getSchemes = query({
  args: {
    category: v.optional(v.string()),
    state: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    if (args.category) {
      return await ctx.db
        .query("schemes")
        .withIndex("by_category", (q) => q.eq("category", args.category!))
        .collect();
    }
    
    return await ctx.db.query("schemes").collect();
  },
});

// Farmer Profile Functions
export const createFarmerProfile = mutation({
  args: {
    name: v.string(),
    phone: v.optional(v.string()),
    location: v.optional(v.string()),
    farmSize: v.optional(v.number()),
    soilType: v.optional(v.string()),
    preferredLanguage: v.optional(v.string()),
    crops: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("farmers", args);
  },
});

export const getFarmerProfile = query({
  args: {
    farmerId: v.id("farmers"),
  },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.farmerId);
  },
});
