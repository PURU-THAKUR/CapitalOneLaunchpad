import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const PhasalApp());
}

class PhasalApp extends StatelessWidget {
  const PhasalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PHASAL - AI Farming Assistant',
      theme: ThemeData(
        primarySwatch: Colors.green,
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.green,
          foregroundColor: Colors.white,
          elevation: 2,
        ),
      ),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
