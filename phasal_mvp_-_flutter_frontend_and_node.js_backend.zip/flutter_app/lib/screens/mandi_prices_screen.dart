import 'package:flutter/material.dart';

class MandiPricesScreen extends StatefulWidget {
  const MandiPricesScreen({super.key});

  @override
  State<MandiPricesScreen> createState() => _MandiPricesScreenState();
}

class _MandiPricesScreenState extends State<MandiPricesScreen> {
  String _selectedCrop = 'Wheat';
  
  // Hardcoded mandi price data
  final Map<String, List<Map<String, String>>> _mandiPrices = {
    'Wheat': [
      {'market': 'Patna', 'price': '₹2200/quintal'},
      {'market': 'Darbhanga', 'price': '₹2150/quintal'},
      {'market': 'Muzaffarpur', 'price': '₹2180/quintal'},
      {'market': 'Gaya', 'price': '₹2170/quintal'},
    ],
    'Rice': [
      {'market': 'Patna', 'price': '₹3200/quintal'},
      {'market': 'Darbhanga', 'price': '₹3150/quintal'},
      {'market': 'Muzaffarpur', 'price': '₹3180/quintal'},
      {'market': 'Begusarai', 'price': '₹3160/quintal'},
    ],
    'Tomato': [
      {'market': 'Patna', 'price': '₹1500/quintal'},
      {'market': 'Muzaffarpur', 'price': '₹1600/quintal'},
      {'market': 'Darbhanga', 'price': '₹1450/quintal'},
      {'market': 'Samastipur', 'price': '₹1550/quintal'},
    ],
  };

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'मंडी भाव',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          
          // Crop selection dropdown
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(8),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedCrop,
                isExpanded: true,
                items: _mandiPrices.keys.map((String crop) {
                  return DropdownMenuItem<String>(
                    value: crop,
                    child: Text(
                      crop == 'Wheat' ? 'गेहूं (Wheat)' :
                      crop == 'Rice' ? 'चावल (Rice)' :
                      'टमाटर (Tomato)',
                      style: const TextStyle(fontSize: 16),
                    ),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  if (newValue != null) {
                    setState(() {
                      _selectedCrop = newValue;
                    });
                  }
                },
              ),
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Price list header
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.green.shade100,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Text(
                    'मंडी का नाम',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Text(
                    'भाव',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.right,
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 10),
          
          // Price list
          Expanded(
            child: ListView.builder(
              itemCount: _mandiPrices[_selectedCrop]?.length ?? 0,
              itemBuilder: (context, index) {
                final priceData = _mandiPrices[_selectedCrop]![index];
                return Card(
                  elevation: 2,
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Text(
                            priceData['market']!,
                            style: const TextStyle(fontSize: 16),
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Text(
                            priceData['price']!,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Colors.green,
                            ),
                            textAlign: TextAlign.right,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          
          // Data source info
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Row(
              children: [
                Icon(Icons.info_outline, color: Colors.blue, size: 20),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'डेटा स्रोत: eNAM, AgMarkNet APIs + Gemini Analysis',
                    style: TextStyle(fontSize: 12, color: Colors.blue),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
