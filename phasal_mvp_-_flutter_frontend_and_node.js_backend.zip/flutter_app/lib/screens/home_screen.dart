import 'package:flutter/material.dart';
import 'camera_analysis_screen.dart';
import 'chatbot_screen.dart';
import 'mandi_prices_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    const CameraAnalysisScreen(),
    const ChatbotScreen(),
    const MandiPricesScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PHASAL - AI कृषि सहायक'),
        centerTitle: true,
      ),
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.camera_alt),
            label: 'फोटो विश्लेषण',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: 'AI सहायक',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.store),
            label: 'मंडी भाव',
          ),
        ],
      ),
    );
  }
}
